 <?php
session_start();
include('includes/database.php');
?>
<!DOCTYPE html>
<html>
<head>
  <?php include("includes/header.php");?>
</head>
<body>
<?php 
include("pages/shared/menu.php"); 
?>
<div class="container">
    <div class="row">
        <div class="col-md-12"> 
        <?php 
         include('pages/product_details.php');
        ?>
        </div>
    </div>
</div>
</body>
</html>