<?php
session_start();
date_default_timezone_set('America/El_Salvador');
include('../includes/database.php');
if(isset($_POST['options'])){
 $options   = $_POST['options'];
 if($options=="add_list"){
  $clients_online   =$_POST['clients_online'];
  $product_id       =$_POST['product_id'];
  $check            = "SELECT lista_compra_cantidad FROM lista_compras WHERE cliente_id='".$clients_online."' AND producto_id='".$product_id."';";
  $select = $link->query($check);
  $num = $select->num_rows;
    if($num>0){
        $request_ = $select->fetch_array(MYSQLI_ASSOC);
          $quantity = $request_["lista_compra_cantidad"];
          $quantity = $quantity + 1;
         $q="UPDATE lista_compras SET lista_compra_cantidad = '".$quantity."' WHERE cliente_id='".$clients_online."' AND producto_id='".$product_id."';";
    }else{
        $q="INSERT INTO lista_compras (producto_id, cliente_id, lista_compra_cantidad) VALUES ('".$product_id."', '".$clients_online."', '1');";
    }
   $request = $link->query($q);
  if($request){
   ?>
   <script>
        alert("PRODUCTO AGREGADO, EXITOSAMENTE");
  </script>
   <?php
  }
 }
 if($options=="view_list"){
     $clients_online   =$_POST['clients_online'];
     $q = "SELECT productos.producto_id AS 'product_id', producto_nombre, producto_precio, lista_compra_cantidad  FROM lista_compras INNER JOIN productos ON (productos.producto_id = lista_compras.producto_id) WHERE lista_compras.cliente_id='".$clients_online."';";
     $select = $link->query($q);
    ?>
    <table class="table table-bordered table-hover text-center">
     <thead>
        <th class="text-center">#</th>
        <th class="text-center">Codigo</th>
        <th class="text-center">Producto</th>
        <th class="text-center">Precio</th>
        <th class="text-center">Cantidad</th>
        <th class="text-center">Total</th>
        <th class="text-center">Accion</th>
     </thead>
     <tbody>
      <?php
     $num = $select->num_rows;
     $n=$mega_total=0;
     if($num>0){
         while($data = $select->fetch_assoc()){
             $product_id        = $data["product_id"];
             $product_name      = $data["producto_nombre"];
             $product_price     = $data["producto_precio"];
             $product_quantity  = $data["lista_compra_cantidad"];
             $total = ($product_quantity*$product_price);
             $mega_total += $total;
            $n++; 
            ?>            
            <tr>
                <td><?=$n;?></td>
                <td><?=$product_id;?></td>
                <td><?=$product_name;?></td>
                <td>$ <?=$product_price;?></td>
                <td><?=$product_quantity;?></td>
                <td><b>$ <?=$total;?></b></td>
                <td>
                    <a href="#" class="btn btn-default" onclick="products_details('<?=$product_id;?>');" >  <span class="glyphicon glyphicon-search" aria-hidden="true"></span></a>
                    <a href="#" class="btn btn-danger" onclick="products_delete('<?=$product_id;?>', '<?=$clients_online;?>');">  <span class="glyphicon glyphicon-trash" aria-hidden="true"></span></a>
                </td>
            </tr>
            <?php
         }
     }else{
       ?>
         <tr>
            <td colspan="7">
                <div class="alert alert-warning text-center" role="alert"><b>NO</b> SE ENCONTRARON RESULTADOS</div>
            </td>
         </tr>
        <?php
     }
     ?>
     </tbody>
     <tfoot style="font-weight:bold;">
        <td colspan="5">SubTotal</td>
        <td>$ <?=$mega_total;?></td>
        <td>&nbsp;</td>
     </tfoot>
    </table>
    <div class="well text-align">
        <center>
        <button type="button" class="btn btn-danger" data-dismiss="modal" style="width:150px;">CANCELAR</button>
        <button type="button" class="btn btn-primary" onclick="send_process_before_invoices();" style="width:150px;">ENVIAR PEDIDO</button>
        </center>
    </div>
    <?php
 }
 if($options=="delete_product_list"){
   $clients_online   =$_POST['clients_online'];
   $product_id       =$_POST['product_id'];
    $q="DELETE FROM lista_compras WHERE cliente_id='".$clients_online."' AND producto_id='".$product_id."';";
     $request = $link->query($q);
      if($request){
       ?>
       <script>
            alert("PRODUCTO ELIMINADO, EXITOSAMENTE");
            view_list_cars();
      </script>
       <?php
   }
 }
 if($options=="process_invoice"){
   $clients_id = $_POST["clients_online"];
   $date_time  = date("YmdHis");
   $success    = 0;
    $q = "SELECT productos.producto_id AS 'product_id',  producto_precio, lista_compra_cantidad  FROM lista_compras INNER JOIN productos ON (productos.producto_id = lista_compras.producto_id) WHERE lista_compras.cliente_id='".$clients_id."';";
    $select = $link->query($q);
    $num=$select->num_rows;
    if($num>0){
        $main = "INSERT INTO ventas_general (cliente_id, venta_fecha, venta_estado) VALUES ('".$clients_id."', '".$date_time."', 'PENDIENTE');";
        $request_main = $link->query($main);
        if($request_main){
         $info_main = $link->query("SELECT venta_id FROM ventas_general WHERE cliente_id='".$clients_id."' AND venta_fecha='".$date_time."' AND  venta_estado='PENDIENTE';");
         $request_ = $info_main->fetch_array(MYSQLI_ASSOC);
          $sales_id = $request_["venta_id"];
          $mega_total=$mega_quantity=0;
          while($data_list = $select->fetch_assoc()){
              $product_id        = $data_list["product_id"];
              $product_price     = $data_list["producto_precio"];
              $product_quantity  = $data_list["lista_compra_cantidad"];
              $total = ($product_quantity*$product_price);
              $mega_quantity += $product_quantity;
              $mega_total += $total;
              $sales_details = "INSERT INTO ventas_detalle (venta_id, producto_id, venta_d_cantidad, venta_d_precio, venta_d_fecha) VALUES ('".$sales_id."', '".$product_id."', '".$product_quantity."', '".$product_price."', '".$date_time."');";
              $request_details = $link->query($sales_details);
          }
          $update_main = $link->query("UPDATE ventas_general SET venta_cantidad='".$mega_quantity."', venta_total='".$mega_total."' WHERE cliente_id='".$clients_id."' AND venta_fecha='".$date_time."' AND  venta_estado='PENDIENTE';");
         $success=1;
        }
     if($success>0){
        $delete_list    ="DELETE FROM lista_compras WHERE cliente_id='".$clients_id."';";
        $request_delete = $link->query($delete_list);
         ?>
            <script>
                alert("ORDEN DE COMPRA ENVIADA.");
                window.location="index.php";
            </script>
        <?php
     }
    }else{
    ?>
        <div class="alert alert-danger" role="alert">ERROR, EXISTE UN PROBLEMA CON LA LISTA DE PRODUCTOS </div>
    <?php
    }
        
 }
}
else{
?>
<script type="text/javascript">
  window.location="index.php";
</script> 
<?php
}
?>