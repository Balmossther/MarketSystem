<div class="row">
  <div class="col-lg-12">
    <div class="input-group">
      <input type="text" class="form-control" id="text_search_products" placeholder="INGRESAR NOMBRE">
      <span class="input-group-btn">
        <button class="btn btn-default" type="button" onclick="search_products();">BUSCAR</button>
      </span>
    </div>
  </div>
</div>
<br>
<div class="list-group">
  <a href="#" class="list-group-item active" style="background-color:#4CAF50;">
    MARCAS REGISTRADAS
  </a>
 <?php
	$request_brand = $link->query("SELECT marca_id, marca_nombre, (SELECT COUNT(producto_id) FROM productos WHERE marca_id=marca.marca_id) AS 'count_data' FROM marca ORDER BY marca_nombre ASC");
	while($data_read_brand =$request_brand ->fetch_assoc()){
		$brand_id 				= $data_read_brand['marca_id'];
		$brand_name 			= $data_read_brand['marca_nombre'];
		$product_brand_count 	= $data_read_brand['count_data'];
	?>
	  <a href="products.php?options=brands&id=<?=$brand_id;?>" class="list-group-item"><?=$brand_name;?>
   		<span class="badge"><?=$product_brand_count; ?></span>
	</a>
  <?php
	}
	?>
</div>