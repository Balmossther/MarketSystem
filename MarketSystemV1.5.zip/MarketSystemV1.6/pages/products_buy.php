<div class="panel panel-success">
  <div class="panel-heading">ULTIMOS PRODUCTOS</div>
  <div class="panel-body">
  No hay Productos para mostrar...
  </div>
</div>