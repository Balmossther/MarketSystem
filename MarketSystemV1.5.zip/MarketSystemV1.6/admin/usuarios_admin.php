<?php
session_start();
if(isset($_SESSION["usuario"])){
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <?php include("includes/header.php");?>
  </head>
  <body>
  <?php
  include('database.php');
  include('menu.php');
  ?>
  <div class="container">
    <h2>
    <i class="fa fa-user-secret" aria-hidden="true"></i>
    ADMINISTRACION DE USUARIOS
    </h2>
    <div class="row">
      <div class="col-md-9">
        <div id="mini_request_users">
        <?php
        if(isset($_GET['x'])){
          $var = $_GET['x'];
          if($var=="01"){
             ?>
             <div class="alert alert-success alert-dismissible" role="alert">
              <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
              <strong>ELIMINADO!</strong> USUARIO ELIMINADO EXITOSAMENTE.
            </div>
             <?php
          }
          if($var=="00"){
            ?>
             <div class="alert alert-success alert-dismissible" role="alert">
              <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
              <strong>USUARIO INGRESADO EXITOSAMENTE.</strong>
            </div>
            <?php
          }
        }
        ?>
        </div>
      </div>
      <div class="col-md-3 text-right">
        <button type="button" class="btn btn-success btn-md" data-toggle="modal" data-target="#modal_details" data-backdrop="static">
          <span class="glyphicon glyphicon-plus" aria-hidden="true"></span> NUEVO USUARIO
        </button>
      </div>
    </div>
    <br>
    <div id="request_list">
    <?php include("shared/users_list.php");?>  
    </div>
   </div>
   <div class="modal fade" id="modal_details" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-md">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
          </div>
          <div class="modal-body">
            <div id="report_data_details">
            <H4>REGISTRO DE USUARIOS</H4>
             <div class="row">
             <div class="col-md-12">
             <form>
                <div class="form-group">
                  <label for="user_name">NOMBRE COMPLETO:</label>
                  <input type="text" class="form-control" id="user_full_name" required>
                </div>
                 <div class="form-group">
                  <label for="user_full_name">USUARIO:</label>
                  <input type="text" class="form-control" id="user_name" required>
                </div>
                <div class="form-group">
                  <label for="passwd">CONTRASEÑA:</label>
                  <input type="password" class="form-control" id="passwd" required>
                </div>
                <div class="form-group">
                  <label for="email">CORREO:</label>
                  <input type="text" class="form-control" id="email" required>
                </div>
                 <div class="form-group">
                  <label for="user_type">TIPO DE USUARIO:</label>
                  <select class="form-control" name="user_type" id="user_type">
                  <option value="ADMINISTRACION">ADMINISTRACION</option>
                  <option value="VENDEDOR">VENDEDOR</option>
                  </select>
                </div>
                <hr>
                <div class="row">
                  <div class="col-md-12 text-center">
                  <div class="btn-group" role="group" aria-label="options_buttons">
                    <button type="button" class="btn btn-danger" data-dismiss="modal" style="width:150px;">SALIR</button>
                    <button type="button" class="btn btn-success" style="width:150px;" onclick="saved_users();">GUARDAR DATOS</button>
                  </div>
                  </div>
                </div>
              </form>
             </div>
             </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="modal fade" id="modal_edits_users" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-md">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
          </div>
          <div class="modal-body">
            <div id="report_data_edits_users">
            </div>
          </div>
        </div>
      </div>
    </div>
   <footer>
     <?php include("includes/footer.php");?>
   </footer>
  </body>
</html>
<?php } ?>