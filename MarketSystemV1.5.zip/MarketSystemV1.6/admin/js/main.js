$(document).ready(function(){
    $('#lists_datatable').dataTable( {
          "iDisplayLength": 100,
             "aLengthMenu": [50, 100,150, 100, ,200, 500, 1000],
          "bJQueryUI": true,
          "bAutoWidth": false,
          "sPaginationType": "full_numbers"
        } );
});
function OnloadDataTable(){
$('#lists_datatable').dataTable( {
      "iDisplayLength": 100,
         "aLengthMenu": [50, 100,150, 100, ,200, 500, 1000],
      "bJQueryUI": true,
      "bAutoWidth": false,
      "sPaginationType": "full_numbers"
    } );
}
function sendlogin(){
	var username = $("#username").val();
	var password = $("#password").val();
	// Checking for blank fields.
	if( username =='' || password ==''){
	$('input[type="text"],input[type="password"]').css("border","2px solid red");
	$('input[type="text"],input[type="password"]').css("box-shadow","0 0 3px red");
	alert("Por favor Ingrese un nombre o contraseña");
	}else{
		var valores = {
                "username" : username,
                "password" : password
        };
        $.ajax({
                data:  valores,
                url:   'login_process.php',
                type:  'post',
                beforeSend: function () {
                        $("#mini_request").html("<script>console.log('verificando');</script>");
                },
                success:  function (response) {
                        $("#mini_request").html(response);
                }
        });
	}
}
//FUNCTIONS USERS
function delete_users(id, options){
        if(options==1){
                var options = "DELETE";
        }
        var data_send = {
                "user_id" : id,
                "options" : options}
        if(confirm('¿Estas seguro que desea eliminar este usuario?'))
    	{
    	  $.ajax({
                data:  data_send,
                url:   'shared/options_users.php',
                type:  'post',
                beforeSend: function () {
                        $("#mini_request_users").html("<script>console.log('verificando');</script>");
                },
                success:  function (response) {
                        $("#mini_request_users").html(response);
                }
          });
    	}
    	else
    	{
    		return false;
    	}
}
function saved_users(){
        var user_name       = $("#user_name").val();
        var user_full_name  = $("#user_full_name").val();
        var passwd          = $("#passwd").val();
        var email           = $("#email").val();
        var user_type       = $('select[name=user_type]').val();
        var options         = "SAVED";
        if($.trim(user_name)==""){ $("#user_name").css("border", "1px solid red"); $("#user_name").focus(); return;  }
        if($.trim(user_full_name)==""){ $("#user_full_name").css("border", "1px solid red"); $("#user_full_name").focus(); return;  }
        if($.trim(passwd)==""){ $("#passwd").css("border", "1px solid red"); $("#passwd").focus(); return;  }
        if($.trim(email)==""){ $("#email").css("border", "1px solid red"); $("#email").focus(); return;  }
        var data_send = {
                "user_name" : user_name,
                "user_full_name" : user_full_name,
                "passwd" : passwd,
                "email" : email,
                "user_type" : user_type,
                "options" : options}
        $.ajax({
                data:  data_send,
                url:   'shared/options_users.php',
                type:  'post',
                beforeSend: function () {
                        $("#mini_request_users").html("<script>console.log('verificando');</script>");
                },
                success:  function (response) {
                        $("#mini_request_users").html(response);
                }
        });

}
function selects_user(){
      var options = "SELECT";
      var data_send = { "options" : options}
        $.ajax({
                data:  data_send,
                url:   'shared/options_users.php',
                type:  'post',
                beforeSend: function () {
                        $("#request_list").html("<script>console.log('verificando');</script>");
                },
                success:  function (response) {
                        $("#request_list").html(response);
                        OnloadDataTable();
                }
        });
}
function edits_user(id_users){
    var options = "EDITS_CONTROLS";
      var data_send = { "user_id":id_users,"options": options}
        $.ajax({
                data:  data_send,
                url:   'shared/options_users.php',
                type:  'post',
                beforeSend: function () {
                        $("#report_data_edits_users").html("<script>console.log('verificando');</script>");
                },
                success:  function (response) {
                        $("#report_data_edits_users").html(response);
                }
        });
    
}
function edits_users(){
    var users_id        = $("#edits_users_id").val();
    var user_name       = $("#edits_user_name").val();
    var user_full_name  = $("#edits_user_full_name").val();
    var passwd          = $("#edits_passwd").val();
    var email           = $("#edits_email").val();
    var user_type       = $('select[name=edits_user_type]').val();
    var user_status     = $('select[name=edits_user_status]').val();
    var options         = "EDITS";
    if($.trim(user_name)==""){ $("#edits_user_name").css("border", "1px solid red"); $("#edits_user_name").focus(); return;  }
    if($.trim(user_full_name)==""){ $("#edits_user_full_name").css("border", "1px solid red"); $("#edits_user_full_name").focus(); return;  }
    if($.trim(passwd)==""){ $("#edits_passwd").css("border", "1px solid red"); $("#edits_passwd").focus(); return;  }
    if($.trim(email)==""){ $("#edits_email").css("border", "1px solid red"); $("#edits_email").focus(); return;  }
    var data_send = {
            "users_id" : users_id,
            "user_name" : user_name,
            "user_full_name" : user_full_name,
            "passwd" : passwd,
            "email" : email,
            "user_type" : user_type,
            "options" : options,
            "user_status":user_status}
    $.ajax({
            data:  data_send,
            url:   'shared/options_users.php',
            type:  'post',
            beforeSend: function () {
                    $("#mini_request_users").html("<script>console.log('verificando');</script>");
            },
            success:  function (response) {
                    $("#mini_request_users").html(response);
            }
    }); 
}
//FUNCTION CATEGORY
function delete_category(id, options){
        if(options==1){
                var options = "DELETE";
        }
        var data_send = {
                "category_id" : id,
                "options" : options}
        if(confirm('¿Estas seguro que desea eliminar esta categoria?'))
    	{
    	  $.ajax({
                data:  data_send,
                url:   'shared/category_options.php',
                type:  'post',
                beforeSend: function () {
                        $("#mini_request_category").html("<script>console.log('verificando');</script>");
                },
                success:  function (response) {
                        $("#mini_request_category").html(response);
                }
          });
    	}
    	else
    	{
    		return false;
    	}
}
function selects_category(){
      var options = "SELECT";
      var data_send = { "options" : options}
        $.ajax({
                data:  data_send,
                url:   'shared/category_options.php',
                type:  'post',
                beforeSend: function () {
                        $("#request_list").html("<script>console.log('verificando');</script>");
                },
                success:  function (response) {
                        $("#request_list").html(response);
                    OnloadDataTable();
                }
        });
}
function saved_category(){
    var category_name           = $("#category_name").val();
    var category_description    = $("#category_description").val();
    var options                 = "SAVED";
    if($.trim(category_name)==""){ $("#category_name").css("border", "1px solid red"); $("#category_name").focus(); return;  }
    if($.trim(category_description)==""){ $("#category_description").css("border", "1px solid red"); $("#category_description").focus(); return;  }
        var data_send = {
                "category_name" : category_name,
                "category_description" : category_description,
                "options" : options
        }
        $.ajax({
                data:  data_send,
                url:   'shared/category_options.php',
                type:  'post',
                beforeSend: function () {
                        $("#mini_request_category").html("<script>console.log('verificando');</script>");
                },
                success:  function (response) {
                        $("#mini_request_category").html(response);
                }
        }); 
}
function edits_category(category_id){
    var options = "EDITS_CONTROLS";
      var data_send = { "category_id":category_id,"options": options}
        $.ajax({
                data:  data_send,
                url:   'shared/category_options.php',
                type:  'post',
                beforeSend: function () {
                    $("#report_data_edits_category").html("<script>console.log('verificando');</script>");
                },
                success:  function (response) {
                    $("#report_data_edits_category").html(response);
                }
        });
    
}
function edits_categories(){
    var category_id        = $("#edits_category_id").val();
    var category_name       = $("#edit_category_name").val();
    var category_descriptions  = $("#edit_category_description").val();
    var options         = "EDITS";
    if($.trim(category_name)==""){ $("#edit_category_name").css("border", "1px solid red"); $("#edit_category_name").focus(); return;  }
    if($.trim(category_descriptions)==""){ $("#edit_category_description").css("border", "1px solid red"); $("#edit_category_description").focus(); return;  }
    var data_send = {
            "category_id" : category_id,
            "category_name" : category_name,
            "category_descriptions" : category_descriptions,
            "options" : options
    }
    $.ajax({
            data:  data_send,
            url:   'shared/category_options.php',
            type:  'post',
            beforeSend: function () {
                    $("#mini_request_category").html("<script>console.log('verificando');</script>");
            },
            success:  function (response) {
                    $("#mini_request_category").html(response);
            }
    }); 
}
//FUNCTION BRANDS
function selects_brand(){
      var options = "SELECT";
      var data_send = { "options" : options}
        $.ajax({
                data:  data_send,
                url:   'shared/brand_options.php',
                type:  'post',
                beforeSend: function () {
                        $("#request_list").html("<script>console.log('verificando');</script>");
                },
                success:  function (response) {
                        $("#request_list").html(response);
                        OnloadDataTable();
                }
        });
}
function saved_brand(){
    var brand_name          = $("#brand_name").val();
    var brand_description   = $("#brand_description").val();
    var options             = "SAVED";
    if($.trim(brand_name)==""){ $("#brand_name").css("border", "1px solid red"); $("#brand_name").focus(); return;  }
    if($.trim(brand_description)==""){ $("#brand_description").css("border", "1px solid red"); $("#brand_description").focus(); return;  }
        var data_send = {
                "brand_name" : brand_name,
                "brand_description" : brand_description,
                "options" : options
        }
        $.ajax({
                data:  data_send,
                url:   'shared/brand_options.php',
                type:  'post',
                beforeSend: function () {
                        $("#mini_request_brand").html("<script>console.log('verificando');</script>");
                },
                success:  function (response) {
                        $("#mini_request_brand").html(response);
                }
        }); 
}
function delete_brand(id, options){
        if(options==1){
                var options = "DELETE";
        }
        var data_send = {
                "brand_id" : id,
                "options" : options}
        if(confirm('¿Estas seguro que desea eliminar esta marca?'))
    	{
    	  $.ajax({
                data:  data_send,
                url:   'shared/brand_options.php',
                type:  'post',
                beforeSend: function () {
                        $("#mini_request_brand").html("<script>console.log('verificando');</script>");
                },
                success:  function (response) {
                        $("#mini_request_brand").html(response);
                }
          });
    	}
    	else
    	{
    		return false;
    	}
}
function edits_brand(brand_id){
    var options = "EDITS_CONTROLS";
      var data_send = { "brand_id":brand_id,"options": options}
        $.ajax({
                data:  data_send,
                url:   'shared/brand_options.php',
                type:  'post',
                beforeSend: function () {
                    $("#report_data_edits_brand").html("<script>console.log('verificando');</script>");
                },
                success:  function (response) {
                    $("#report_data_edits_brand").html(response);
                }
        });
}
function edits_brands(){
    var brand_id        = $("#edits_brand_id").val();
    var brand_name       = $("#edit_brand_name").val();
    var brand_descriptions  = $("#edit_brand_description").val();
    var options         = "EDITS";
    if($.trim(brand_name)==""){ $("#edit_brand_name").css("border", "1px solid red"); $("#edit_brand_name").focus(); return;  }
    if($.trim(brand_descriptions)==""){ $("#edit_brand_description").css("border", "1px solid red"); $("#edit_brand_description").focus(); return;  }
    var data_send = {
            "brand_id" : brand_id,
            "brand_name" : brand_name,
            "brand_descriptions" : brand_descriptions,
            "options" : options
    }
    $.ajax({
            data:  data_send,
            url:   'shared/brand_options.php',
            type:  'post',
            beforeSend: function () {
                    $("#mini_request_brand").html("<script>console.log('verificando');</script>");
            },
            success:  function (response) {
                    $("#mini_request_brand").html(response);
            }
    }); 
}
//FUNCTION MODELS
function selects_models(){
      var options = "SELECT";
      var data_send = { "options" : options}
        $.ajax({
                data:  data_send,
                url:   'shared/model_options.php',
                type:  'post',
                beforeSend: function () {
                        $("#request_list").html("<script>console.log('verificando');</script>");
                },
                success:  function (response) {
                        $("#request_list").html(response);
                        OnloadDataTable();
                }
        });
}
function saved_new_models(){
    var brand_id            = $('select[name=brand_type]').val();
    var models_name         = $("#models_name").val();
    var models_descriptions = $("#models_descriptions").val();
    var options             = "SAVED";
    if($.trim(models_name)==""){ $("#models_name").css("border", "1px solid red"); $("#models_name").focus(); return;  }
    if($.trim(models_descriptions)==""){ $("#models_descriptions").css("border", "1px solid red"); $("#models_descriptions").focus(); return;  }
        var data_send = {
                "brand_id" : brand_id,
                "models_name" : models_name,
                "models_descriptions" : models_descriptions,
                "options" : options
        }
        $.ajax({
                data:  data_send,
                url:   'shared/model_options.php',
                type:  'post',
                beforeSend: function () {
                    $("#mini_request_models").html("<script>console.log('verificando');</script>");
                },
                success:  function (response) {
                    $("#mini_request_models").html(response);
                }
        }); 
}
function delete_models(id, options){
        if(options==1){
                var options = "DELETE";
        }
        var data_send = {
                "models_id" : id,
                "options" : options}
        if(confirm('¿Estas seguro que desea eliminar este modelo?'))
        {
          $.ajax({
                data:  data_send,
                url:   'shared/model_options.php',
                type:  'post',
                beforeSend: function () {
                    $("#mini_request_models").html("<script>console.log('verificando');</script>");
                },
                success:  function (response) {
                    $("#mini_request_models").html(response);
                }
          });
        }
        else
        {
            return false;
        }
}
function edits_models(model_id){
    var options = "EDITS_CONTROLS";
      var data_send = { "model_id":model_id,"options": options}
        $.ajax({
                data:  data_send,
                url:   'shared/model_options.php',
                type:  'post',
                beforeSend: function () {
                    $("#report_data_edits_models").html("<script>console.log('verificando');</script>");
                },
                success:  function (response) {
                    $("#report_data_edits_models").html(response);
                }
        });
}
function edit_saved_models(){
    var brand_id            = $('select[name=edit_brand_type]').val();
    var models_name         = $("#edit_model_name").val();
    var models_descriptions = $("#edit_model_description").val();
    var model_id            = $("#edits_model_id").val();
    var options             = "EDITS";
    if($.trim(models_name)==""){ $("#edit_model_name").css("border", "1px solid red"); $("#edit_model_name").focus(); return;  }
    if($.trim(models_descriptions)==""){ $("#edit_model_description").css("border", "1px solid red"); $("#edit_model_description").focus(); return;  }
        var data_send = {
                "model_id" : model_id,
                "brand_id" : brand_id,
                "models_name" : models_name,
                "models_descriptions" : models_descriptions,
                "options" : options
        }
        $.ajax({
                data:  data_send,
                url:   'shared/model_options.php',
                type:  'post',
                beforeSend: function () {
                    $("#mini_request_models").html("<script>console.log('verificando');</script>");
                },
                success:  function (response) {
                    $("#mini_request_models").html(response);
                }
        });
}
//FUNTION CLIENTS
function selects_clients(){
      var options = "SELECT";
      var data_send = { "options" : options}
        $.ajax({
                data:  data_send,
                url:   'shared/clients_options.php',
                type:  'post',
                beforeSend: function () {
                        $("#request_list").html("<script>console.log('verificando');</script>");
                },
                success:  function (response) {
                        $("#request_list").html(response);
                        OnloadDataTable();
                }
        });
}
function saved_new_clients(){
    var clients_name            = $("#clients_name").val();
    var clients_last_name       = $("#clients_last_name").val();
    var clients_passwd          = $("#clients_passwd").val();
    var clients_email           = $("#clients_email").val();
    var clients_cellphone       = $("#clients_cellphone").val();
    var clients_date_borth      = $("#clients_date_borth").val();
    var clients_address         = $("#clients_address").val();
    var clients_country         = $('select[name=clients_country]').val();
    var clients_departaments    = $('select[name=clients_departaments]').val();
    var options                 = "SAVED";
    if($.trim(clients_name)==""){ $("#clients_name").css("border", "1px solid red"); $("#clients_name").focus(); return;  }
    if($.trim(clients_last_name)==""){ $("#clients_last_name").css("border", "1px solid red"); $("#clients_last_name").focus(); return;  }
        var data_send = {
                "clients_name" : clients_name,
                "clients_last_name" : clients_last_name,
                "clients_passwd" : clients_passwd,
                "clients_email" : clients_email,
                "clients_cellphone" : clients_cellphone,
                "clients_date_borth" : clients_date_borth,
                "clients_address" : clients_address,
                "clients_country" : clients_country,
                "clients_departaments" : clients_departaments,
                "options" : options
        }
        $.ajax({
                data:  data_send,
                url:   'shared/clients_options.php',
                type:  'post',
                beforeSend: function () {
                    $("#mini_request_clients").html("<script>console.log('verificando');</script>");
                },
                success:  function (response) {
                    $("#mini_request_clients").html(response);
                }
        }); 
}
function delete_clients(id, options){
        if(options==1){
                var options = "DELETE";
        }
        var data_send = {
                "clients_id" : id,
                "options" : options}
        if(confirm('¿Estas seguro que desea eliminar este cliente?'))
        {
          $.ajax({
                data:  data_send,
                url:   'shared/clients_options.php',
                type:  'post',
                beforeSend: function () {
                    $("#mini_request_clients").html("<script>console.log('verificando');</script>");
                },
                success:  function (response) {
                    $("#mini_request_clients").html(response);
                }
          });
        }
        else
        {
            return false;
        }
}
function edits_clients(clients_id){
    var options = "EDITS_CONTROLS";
      var data_send = { "clients_id":clients_id,"options": options}
        $.ajax({
                data:  data_send,
                url:   'shared/clients_options.php',
                type:  'post',
                beforeSend: function () {
                    $("#report_data_edits_client").html("<script>console.log('verificando');</script>");
                },
                success:  function (response) {
                    $("#report_data_edits_client").html(response);
                }
        });
}
function edit_saved_clients(){
    var clients_name            = $("#edits_clients_name").val();
    var clients_last_name       = $("#edits_clients_last_name").val();
    var clients_passwd          = $("#edits_clients_passwd").val();
    var clients_email           = $("#edits_clients_email").val();
    var clients_cellphone       = $("#edits_clients_cellphone").val();
    var clients_date_borth      = $("#edits_clients_date_borth").val();
    var clients_address         = $("#edits_clients_address").val();
    var clients_country         = $('select[name=edits_clients_country]').val();
    var clients_departaments    = $('select[name=edits_clients_departaments]').val();
    var clients_id              = $("#edits_clients_id").val();
    var options                 = "EDITS";
    if($.trim(clients_name)==""){ $("#edits_clients_name").css("border", "1px solid red"); $("#edits_clients_name").focus(); return;  }
    if($.trim(clients_last_name)==""){ $("#edits_clients_last_name").css("border", "1px solid red"); $("#edits_clients_last_name").focus(); return;  }
        var data_send = {
                "clients_id" : clients_id,
                "clients_name" : clients_name,
                "clients_last_name" : clients_last_name,
                "clients_passwd" : clients_passwd,
                "clients_email" : clients_email,
                "clients_cellphone" : clients_cellphone,
                "clients_date_borth" : clients_date_borth,
                "clients_address" : clients_address,
                "clients_country" : clients_country,
                "clients_departaments" : clients_departaments,
                "options" : options
        }
        $.ajax({
                data:  data_send,
                url:   'shared/clients_options.php',
                type:  'post',
                beforeSend: function () {
                    $("#mini_request_clients").html("<script>console.log('verificando');</script>");
                },
                success:  function (response) {
                    $("#mini_request_clients").html(response);
                }
        });
}
//FUNTION PRODUCTS
function selects_products(){
  var options = "SELECT";
  var data_send = { "options" : options}
    $.ajax({
            data:  data_send,
            url:   'shared/product_options.php',
            type:  'post',
            beforeSend: function () {
                    $("#request_list").html("<script>console.log('verificando');</script>");
            },
            success:  function (response) {
                    $("#request_list").html(response);
                    OnloadDataTable();
            }
    });
}
function saved_new_product(){
    var product_category_type= $('select[name=product_category_type]').val();
    var product_brand_type   = $('select[name=product_brand_type]').val();
    var product_model_type   = $('select[name=product_model_type]').val();
    var products_name        = $("#products_name").val();
    var products_descriptions= $("#products_descriptions").val();
    var products_price       = $("#products_price").val();
    var products_quantity    = $("#products_quantity").val();
    var url_img    			 = $("#url_img").val();
    var options              = "SAVED";
    if($.trim(products_name)==""){ $("#products_name").css("border", "1px solid red"); $("#products_name").focus(); return;  }
    if($.trim(products_descriptions)==""){ $("#products_descriptions").css("border", "1px solid red"); $("#products_descriptions").focus(); return;  }
    if($.trim(products_price)==""){ $("#products_price").css("border", "1px solid red"); $("#products_price").focus(); return;  }
    if($.trim(products_quantity)==""){ $("#products_quantity").css("border", "1px solid red"); $("#products_quantity").focus(); return;  }
        var data_send = {
            "products_name" : products_name,
            "products_descriptions" : products_descriptions,
            "products_price" : products_price,
            "products_quantity" : products_quantity,
            "product_category_type" : product_category_type,
            "product_brand_type" : product_brand_type,
            "product_model_type" : product_model_type,
            "url_img" : url_img,
            "options" : options
        }
        $.ajax({
                data:  data_send,
                url:   'shared/product_options.php',
                type:  'post',
                beforeSend: function () {
                    $("#mini_request_products").html("<script>console.log('verificando');</script>");
                },
                success:  function (response) {
                    $("#mini_request_products").html(response);
                }
        }); 
}
function delete_products(id, options){
        if(options==1){
                var options = "DELETE";
        }
        var data_send = {
                "product_id" : id,
                "options" : options}
        if(confirm('¿Estas seguro que desea eliminar este producto?'))
        {
          $.ajax({
                data:  data_send,
                url:   'shared/product_options.php',
                type:  'post',
                beforeSend: function () {
                    $("#mini_request_products").html("<script>console.log('verificando');</script>");
                },
                success:  function (response) {
                    $("#mini_request_products").html(response);
                }
          });
        }
        else
        {
            return false;
        }
}
function edits_products(product_id){
    var options = "EDITS_CONTROLS";
      var data_send = { "product_id":product_id,"options": options}
        $.ajax({
                data:  data_send,
                url:   'shared/product_options.php',
                type:  'post',
                beforeSend: function () {
                    $("#report_data_edits_products").html("<script>console.log('verificando');</script>");
                },
                success:  function (response) {
                    $("#report_data_edits_products").html(response);
                }
        });
}
function edit_saved_products(){
    var product_category_type= $('select[name=edit_product_category_type]').val();
    var product_brand_type   = $('select[name=edit_product_brand_type]').val();
    var product_model_type   = $('select[name=edit_product_model_type]').val();
    var products_name        = $("#edit_products_name").val();
    var products_descriptions= $("#edit_products_descriptions").val();
    var products_price       = $("#edit_products_price").val();
    var products_quantity    = $("#edit_products_quantity").val();
    var product_id           = $("#edit_product_id").val();
    var url_img              = $("#edit_url_img").val();
    var options              = "EDITS";
    if($.trim(products_name)==""){ $("#edit_products_name").css("border", "1px solid red"); $("#edit_products_name").focus(); return;  }
    if($.trim(products_descriptions)==""){ $("#edit_products_descriptions").css("border", "1px solid red"); $("#edit_products_descriptions").focus(); return;  }
    if($.trim(products_price)==""){ $("#edit_products_price").css("border", "1px solid red"); $("#edit_products_price").focus(); return;  }
    if($.trim(products_quantity)==""){ $("#edit_products_quantity").css("border", "1px solid red"); $("#edit_products_quantity").focus(); return;  }
        var data_send = {
            "product_id" : product_id,
            "products_name" : products_name,
            "products_descriptions" : products_descriptions,
            "products_price" : products_price,
            "products_quantity" : products_quantity,
            "product_category_type" : product_category_type,
            "product_brand_type" : product_brand_type,
            "product_model_type" : product_model_type,
            "url_img" : url_img,
            "options" : options
        }
        $.ajax({
                data:  data_send,
                url:   'shared/product_options.php',
                type:  'post',
                beforeSend: function () {
                    $("#mini_request_products").html("<script>console.log('verificando');</script>");
                },
                success:  function (response) {
                    $("#mini_request_products").html(response);
                }
        }); 
}
//FUNCTION SALES
function generate_reports_sales(){
    var date_i          = $("#date_i").val();
    var date_f          = $("#date_f").val();
    var sales_status    = $('select[name=sales_status]').val();
    var options         = "REPORTS_SALES";
    var data_send = {
            "date_i" : date_i,
            "date_f" : date_f,
            "sales_status" : sales_status,
            "options" : options
        }
        $.ajax({
                data:  data_send,
                url:   'shared/sales_options.php',
                type:  'post',
                beforeSend: function () {
                    $("#request_list").html("<script>console.log('verificando');</script>");
                },
                success:  function (response) {
                    $("#request_list").html(response);
                }
        });
}
function sales_details(sales_id, status){
    var options         = "REPORTS_SALES_DETAILS";
    var data_send = {
            "status" : status,
            "sales_id" : sales_id,
            "options" : options
        }
        $.ajax({
                data:  data_send,
                url:   'shared/sales_options.php',
                type:  'post',
                beforeSend: function () {
                    $("#report_data_details").html("<script>console.log('verificando');</script>");
                },
                success:  function (response) {
                    $("#report_data_details").html(response);
                }
        }); 
}
function sales_rejected(sales_id){
    var options         = "REPORTS_SALES_REJECTED";
    var data_send = {
            "sales_id" : sales_id,
            "options" : options
        }
        $.ajax({
                data:  data_send,
                url:   'shared/sales_options.php',
                type:  'post',
                beforeSend: function () {
                    $("#mini_request_modal_sales").html("<script>console.log('verificando');</script>");
                },
                success:  function (response) {
                    $("#mini_request_modal_sales").html(response);
                }
        }); 
}
function sales_aproved(sales_id){
   var options         = "REPORTS_SALES_APROVED";
    var data_send = {
            "sales_id" : sales_id,
            "options" : options
        }
        $.ajax({
                data:  data_send,
                url:   'shared/sales_options.php',
                type:  'post',
                beforeSend: function () {
                    $("#mini_request_modal_sales").html("<script>console.log('verificando');</script>");
                },
                success:  function (response) {
                    $("#mini_request_modal_sales").html(response);
                }
        }); 
}