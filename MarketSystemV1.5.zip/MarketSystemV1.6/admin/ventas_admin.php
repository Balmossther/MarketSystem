<?php
session_start();
date_default_timezone_set('America/El_Salvador');
if(isset($_SESSION["usuario"])){
$date_f= date('Y-m-d');
$date_i= date("Y-m-d", strtotime("$date_f -1 day"));
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <?php include("includes/header.php");?>
    <script src="//code.jquery.com/jquery-migrate-1.2.1.min.js"></script>
    <script>
    $(function() {
    $( "#date_i" ).datepicker({dateFormat: 'yy-mm-dd', minDate: 0, maxDate: "+0M +5D"  });
    $( "#date_f" ).datepicker({dateFormat: 'yy-mm-dd', minDate: 0, maxDate: "+0M +5D"  });
    });
    </script>
  </head>
  <body>
  <?php
  include('database.php');
  include('menu.php');
  ?>
  <div class="container">
    <h2>
    <i class="fa fa-cart-arrow-down" aria-hidden="true"></i>
        ADMINISTRACION DE ORDENES DE VENTA
    </h2>
     <div class="well row">
       <div class="col-md-3 text-center">
           <span style="font-size:11px;">SELECCIONAR FECHA INICIAL</span>
            <input type=text id='date_i' name='date_i' value="<?=$date_i;?>" class="form-control"  readonly tabindex="2" style="width:125px;text-align:center;cursor:pointer;margin:0 auto;">
       </div>
        <div class="col-md-3 text-center">
            <span style="font-size:11px;">SELECCIONAR FECHA FINAL</span>
            <input type=text id='date_f' name='date_f' value="<?=$date_f;?>" class="form-control"  readonly tabindex="2" style="width:125px;text-align:center;cursor:pointer;margin:0 auto;">
       </div>
        <div class="col-md-3 text-center">
           <span style="font-size:11px;">FILTAR ESTADO:</span>
          <select id="sales_status" name="sales_status" class="form-control">
              <option value="0">(TODOS)</option>
              <option value="PENDIENTE">PENDIENTE</option>
              <option value="APROBADO">APROBADO</option>
            </select>
       </div>
      <div class="col-md-3 text-center">
          <br>
          <button type="button" onclick="generate_reports_sales();" class="btn btn-primary">GENERAR REPORTE</button>
      </div>
     </div>
    <br>
    <div id="request_list">
    <?php ///include("shared/model_list.php");?>  
    </div>
   </div>
   <div class="modal fade" id="modal_details" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
          </div>
          <div class="modal-body">
            <div id="report_data_details">
            </div>
          </div>
        </div>
      </div>
    </div>
   <footer>
     <?php include("includes/footer.php");?>
   </footer>
  </body>
</html>
<?php } ?>