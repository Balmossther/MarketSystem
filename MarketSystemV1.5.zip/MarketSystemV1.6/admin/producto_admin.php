<?php
session_start();
if(isset($_SESSION["usuario"])){
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <?php include("includes/header.php");?>
  </head>
  <body>
  <?php
  include('database.php');
  include('menu.php');
  ?>
  <div class="container">
    <h2>
    <i class="fa fa-server" aria-hidden="true"></i>
    ADMINISTRACION DE PRODUCTOS
    </h2>
    <div class="row">
      <div class="col-md-9">
        <div id="mini_request_products"></div>
      </div>
      <div class="col-md-3 text-right">
        <button type="button" class="btn btn-success btn-md" data-toggle="modal" data-target="#modal_details" data-backdrop="static">
          <span class="glyphicon glyphicon-plus" aria-hidden="true"></span> NUEVO PRODUCTO
        </button>
      </div>
    </div>
    <br>
    <div id="request_list">
    <?php include("shared/product_list.php");?>  
    </div>
   </div>
   <div class="modal fade" id="modal_details" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-md">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
          </div>
          <div class="modal-body">
            <div id="report_data_details">
            <center><H4>REGISTRO DE NUEVOS MODELOS</H4></center>
			<hr>
             <div class="row">
             <div class="col-md-12">
             <form>
               <div class="form-group">
                  <label for="product_category_type">SELECCIONE UNA CATEGORIA:</label>
                  <select class="form-control" name="product_category_type" id="product_category_type">
                  <?php
                  $data = $link->query("SELECT categoria_id, categoria_nombre FROM categorias;");
                  while($data_brand = $data->fetch_assoc()){
                    $category_id            = $data_brand['categoria_id'];
                    $category_name          = $data_brand['categoria_nombre'];
                    ?>
                    <option value='<?=$category_id?>'><?=$category_name;?></option>
                    <?php
                  }
                  ?>
                  </select>
              </div>
               <div class="form-group">
                  <label for="product_brand_type">SELECCIONE UNA MARCA:</label>
                  <select class="form-control" name="product_brand_type" id="product_brand_type">
                  <?php
                  $data = $link->query("SELECT marca_id, marca_nombre, marca_descripcion FROM marca;");
                  while($data_brand = $data->fetch_assoc()){
                    $brand_id            = $data_brand['marca_id'];
                    $brand_name          = $data_brand['marca_nombre'];
                    ?>
                    <option value='<?=$brand_id?>'><?=$brand_name;?></option>
                    <?php
                  }
                  ?>
                  </select>
              </div>
               <div class="form-group">
                  <label for="product_model_type">SELECCIONE UN MODELO:</label>
                  <select class="form-control" name="product_model_type" id="product_model_type">
                  <?php
                  $data = $link->query("SELECT modelo_id, marca_id, modelo_nombre, modelo_descripcion FROM modelo;");
                  while($data_brand = $data->fetch_assoc()){
                    $model_id            = $data_brand['modelo_id'];
                    $model_brand_id      = $data_brand['marca_id'];
                    $model_name          = $data_brand['modelo_nombre'];
                    ?>
                    <option value='<?=$model_id?>'><?=$model_name;?></option>
                    <?php
                  }
                  ?>
                  </select>
              </div>              
               <div class="form-group">
                  <label for="products_name">NOMBRE:</label>
                  <input type="text" class="form-control" id="products_name" required>
                </div>
               <div class="form-group">
                  <label for="products_descriptions">DESCRIPCION:</label>
                  <input type="text" class="form-control" id="products_descriptions" required>
                </div>
			   	<div class="row">
					<div class="col-md-6 text-center">
						<div class="form-group">
						  <label for="products_price">PRECIO UNIDAD:</label>
						  <input type="text" class="form-control" id="products_price" required>
						</div>
					</div>
					<div class="col-md-6 text-center">
						<div class="form-group">
						  <label for="products_quantity">CANTIDAD O EXISTENCIAS:</label>
						  <input type="text" class="form-control" id="products_quantity" required>
						</div>
					</div>
				</div>
				<div class="form-group">
					<label for="url_img">AGREGAR ENLACE DE INTERNET PARA IMAGEN:</label>
					<input type="text" class="form-control" id="url_img" required>
				  	<!--<div>
					  <!-- Nav tabs
					  <ul class="nav nav-tabs" role="tablist">
						<li role="presentation" class="active"><a href="#upload_url" aria-controls="upload_url" role="tab" data-toggle="tab">ENLACE DE INTERNET</a></li>
					  </ul>
					  <!-- Tab panes 
					  <div class="tab-content">
						<div role="tabpanel" class="tab-pane active" id="upload_url">
							<label for="url_img">ENLACE DE INTERNET:</label>
						  	<input type="text" class="form-control" id="url_img" required>
						</div>
					  </div>
					</div>-->
				</div>
                <hr>
                <div class="row">
                  <div class="col-md-12 text-center">
                  <div class="btn-group" role="group" aria-label="options_buttons">
                    <button type="button" class="btn btn-danger" data-dismiss="modal" style="width:175px;">SALIR</button>
                    <button type="button" class="btn btn-success" style="width:175px;" onclick="saved_new_product()">GUARDAR PRODUCTO</button>
                  </div>
                  </div>
                </div>
              </form>
             </div>
             </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="modal fade" id="modal_edits_products" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-md">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
          </div>
          <div class="modal-body">
            <div id="report_data_edits_products">
            </div>
          </div>
        </div>
      </div>
    </div>
   <footer>
     <?php include("includes/footer.php");?>
   </footer>
  </body>
</html>
<?php } ?>