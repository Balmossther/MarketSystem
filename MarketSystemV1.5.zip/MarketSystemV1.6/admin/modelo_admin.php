<?php
session_start();
if(isset($_SESSION["usuario"])){
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <?php include("includes/header.php");?>
  </head>
  <body>
  <?php
  include('database.php');
  include('menu.php');
  ?>
  <div class="container">
    <h2>
    <i class="fa fa-exchange" aria-hidden="true"></i> 
    ADMINISTRACION DE MODELOS
    </h2>
    <div class="row">
      <div class="col-md-9">
        <div id="mini_request_models"></div>
      </div>
      <div class="col-md-3 text-right">
        <button type="button" class="btn btn-success btn-md" data-toggle="modal" data-target="#modal_details" data-backdrop="static">
          <span class="glyphicon glyphicon-plus" aria-hidden="true"></span> NUEVO MODELO
        </button>
      </div>
    </div>
    <br>
    <div id="request_list">
    <?php include("shared/model_list.php");?>  
    </div>
   </div>
   <div class="modal fade" id="modal_details" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-md">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
          </div>
          <div class="modal-body">
            <div id="report_data_details">
            <H4>REGISTRO DE NUEVOS MODELOS</H4>
             <div class="row">
             <div class="col-md-12">
             <form>
              <div class="form-group">
                  <label for="brand_type">SELECCIONE UNA MARCA:</label>
                  <select class="form-control" name="brand_type" id="brand_type">
                  <?php
                  $data = $link->query("SELECT marca_id, marca_nombre, marca_descripcion FROM marca;");
                  while($data_brand = $data->fetch_assoc()){
                    $brand_id            = $data_brand['marca_id'];
                    $brand_name          = $data_brand['marca_nombre'];
                    ?>
                    <option value='<?=$brand_id?>'><?=$brand_name;?></option>
                    <?php
                  }
                  ?>
                  </select>
              </div>
                <div class="form-group">
                  <label for="models_name">NOMBRE:</label>
                  <input type="text" class="form-control" id="models_name" required>
                </div>
                 <div class="form-group">
                  <label for="models_descriptions">DESCRIPCION:</label>
                  <input type="text" class="form-control" id="models_descriptions" required>
                </div>
                <hr>
                <div class="row">
                  <div class="col-md-12 text-center">
                  <div class="btn-group" role="group" aria-label="options_buttons">
                    <button type="button" class="btn btn-danger" data-dismiss="modal" style="width:150px;">SALIR</button>
                    <button type="button" class="btn btn-success" style="width:150px;" onclick="saved_new_models()">GUARDAR MODELO</button>
                  </div>
                  </div>
                </div>
              </form>
             </div>
             </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="modal fade" id="modal_edits_models_" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-md">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
          </div>
          <div class="modal-body">
            <div id="report_data_edits_models">
            </div>
          </div>
        </div>
      </div>
    </div>
   <footer>
     <?php include("includes/footer.php");?>
   </footer>
  </body>
</html>
<?php } ?>