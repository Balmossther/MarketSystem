<?php
$server="localhost";
$user="root";
$pass="";
$port="3307";
$db="tienda_online";
$link = new mysqli($server, $user, $pass, $db);
if ($link->connect_errno) {
    echo "Fallo al conectar a MySQL: (" . $link->connect_errno .")" . $link->connect_error;
}
?>