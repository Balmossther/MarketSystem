<table id="lists_datatable" class="table table-hover table-bordered text-center">
 <thead style="text-align:center;font-weight:bold;">
  <tr class="info">
    <td>#</td>
    <td>CODIGO</td>
    <td>NOMBRE</td>
    <td>DESCRIPCION</td>
    <td>ACCIONES</td>
  </tr>
 </thead>
 <tbody>
  <?php
  $data = $link->query("SELECT marca_id, marca_nombre, marca_descripcion FROM marca;");
  $n=0;
  while($data_brand = $data->fetch_assoc()){
    $brand_id            = $data_brand['marca_id'];
    $brand_name          = $data_brand['marca_nombre'];
    $brand_description   = $data_brand['marca_descripcion'];
    $data_ckeck         = $link->query("SELECT COUNT(modelo_id) AS 'count_brand' FROM modelo WHERE marca_id='".$brand_id."';");
      $request_check    = $data_ckeck->fetch_array(MYSQLI_ASSOC);
      $check_brand      = $request_check['count_brand'];
    $n++;
    ?>
    <tr>
      <td><?=$n;?></td>
      <td><?=$brand_id;?></td>
      <td><?=$brand_name;?></td>
      <td><?=$brand_description;?></td>
      <td style="text-align:center;">
        <div class="btn-group" role="group" aria-label="...">
            <button type="button" class="btn btn-info" onclick="edits_brand(<?=$brand_id;?>);" data-toggle="modal" data-target="#modal_edits_brand" data-backdrop="static">
              <span class="glyphicon glyphicon-pencil" aria-hidden="true"></span>
          </button>
            <?php
            if($check_brand>0){
            ?>
            <button type="button" class="btn btn-danger" onclick="" disabled>
              <span class="glyphicon glyphicon-trash" aria-hidden="true"></span>
              </button>
            <?php
            }else{
            ?>
            <button type="button" class="btn btn-danger" onclick="delete_brand('<?=$brand_id;?>', '1');">
              <span class="glyphicon glyphicon-trash" aria-hidden="true"></span>
              </button>
            <?php
            }
            ?>
        </div>
      </td>
    </tr>
    <?php
  }
  ?>
 </tbody>
</table>