<table id="lists_datatable" class="table table-hover table-bordered text-center">
 <thead style="text-align:center;font-weight:bold;">
  <tr class="info">
    <td>#</td>
    <td>CODIGO</td>
    <td>NOMBRE</td>
    <td>DESCRIPCION</td>
    <td>ACCIONES</td>
  </tr>
 </thead>
 <tbody>
  <?php
  $data = $link->query("SELECT categoria_id, categoria_nombre, categoria_descripcion FROM categorias;");
  $n=0;
  while($data_category = $data->fetch_assoc()){
    $category_id            = $data_category['categoria_id'];
    $category_name          = $data_category['categoria_nombre'];
    $category_description   = $data_category['categoria_descripcion'];
    $data_ckeck         = $link->query("SELECT COUNT(producto_id) AS 'count' FROM productos WHERE categoria_id='".$category_id."';");
    $request_check    = $data_ckeck->fetch_array(MYSQLI_ASSOC);
    $check_count      = $request_check['count'];
    $n++;
    ?>
    <tr>
      <td><?=$n;?></td>
      <td><?=$category_id;?></td>
      <td><?=$category_name;?></td>
      <td><?=$category_description;?></td>
      <td style="text-align:center;">
        <div class="btn-group" role="group" aria-label="...">
           <button type="button" class="btn btn-info" onclick="edits_category(<?=$category_id;?>);" data-toggle="modal" data-target="#modal_edits_category" data-backdrop="static">
              <span class="glyphicon glyphicon-pencil" aria-hidden="true"></span>
          </button>
        <?php
        if($check_count>0){
          ?>
          <button type="button" class="btn btn-danger" disabled>
          <span class="glyphicon glyphicon-trash" aria-hidden="true"></span>
          </button>
            <?php
        }else{
        ?>
          <button type="button" class="btn btn-danger" onclick="delete_category('<?=$category_id;?>', '1');">
          <span class="glyphicon glyphicon-trash" aria-hidden="true"></span>
          </button>
            <?php
            }
          ?>
        </div>
      </td>
    </tr>
    <?php
  }
  ?>
 </tbody>
</table>