<?php
session_start();
include('../database.php');
if($_POST){
$options  =$_POST['options'];
  if($options=="SELECT"){
    include("model_list.php");
  }
  if($options=="SAVED"){
    $brand_id             = $_POST['brand_id'];
    $models_name          = $_POST['models_name'];
    $models_descriptions  = $_POST['models_descriptions'];
     $request = $link->query("INSERT INTO modelo (marca_id, modelo_nombre, modelo_descripcion) VALUES ('".$brand_id."', '".$models_name."', '".$models_descriptions."');");
    if($request){
      ?>
            <div class="alert alert-success alert-dismissible" role="alert">
              <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
              <strong>NUEVO MODELOS CREADO EXITOSAMENTE.</strong>
            </div>
       <script>
            selects_models();
            $("#modal_details").modal('hide');
      </script>
      <?php
    }
  }
  if($options=="DELETE"){
    $models_id  =$_POST['models_id'];
    $request    = $link->query("DELETE FROM modelo WHERE modelo_id='".$models_id."';");
    if($request){
       ?> 
        <div class="alert alert-success alert-dismissible" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <strong>MODELO ELIMINADO!</strong> EXITOSAMENTE.
         </div>
       <script>
           selects_models();
      </script>
      <?php
    }
  }
  if($options=="EDITS_CONTROLS"){
      $model_id  =$_POST['model_id'];
      $data = $link->query("SELECT marca_id, modelo_nombre, modelo_descripcion FROM `modelo` WHERE modelo_id='".$model_id."';");
      $request = $data->fetch_array(MYSQLI_ASSOC);
      $brand_id = $request['marca_id'];
      $model_name = $request['modelo_nombre'];
      $model_description = $request['modelo_descripcion'];
    ?>
    <H4>EDITAR DATOS DE MODELO</H4>
    <div class="row">
     <div class="col-md-12">
     <form>
        <div class="form-group">
          <label for="brand_type">SELECCIONE UNA MARCA:</label>
          <select class="form-control" name="edit_brand_type" id="brand_type">
          <?php
          $data = $link->query("SELECT marca_id, marca_nombre, marca_descripcion FROM marca;");
          while($data_brand = $data->fetch_assoc()){
            $brand_id_            = $data_brand['marca_id'];
            $brand_name_          = $data_brand['marca_nombre'];
            if($brand_id==$brand_id_){
              ?>
              <option value='<?=$brand_id_?>' selected><?=$brand_name_;?></option>
              <?php
            }else{
              ?>
              <option value='<?=$brand_id_?>'><?=$brand_name_;?></option>
              <?php
            }
          }
          ?>
          </select>
        </div>
        <div class="form-group">
           <label for="user_name">NOMBRE:</label>
             <input type="text" class="form-control" id="edit_model_name" value="<?=$model_name;?>" required>
        </div>
         <div class="form-group">
          <label for="user_full_name">DESCRIPCION</label>
          <input type="text" class="form-control" id="edit_model_description" value="<?=$model_description;?>" required>
        </div>
        <hr>
        <input type="hidden" id="edits_model_id" value="<?=$model_id;?>" />
        <div class="row">
          <div class="col-md-12 text-center">
          <div class="btn-group" role="group" aria-label="options_buttons">
            <button type="button" class="btn btn-danger" data-dismiss="modal" style="width:150px;">SALIR</button>
            <button type="button" class="btn btn-success" style="width:150px;" onclick="edit_saved_models();">GUARDAR CAMBIOS</button>
          </div>
          </div>
        </div>
      </form>
     </div>
     </div>
  <?php
  }
  if($options=="EDITS"){
    $model_id             = $_POST['model_id'];
    $brand_id             = $_POST['brand_id'];
    $models_name          = $_POST['models_name'];
    $models_descriptions  = $_POST['models_descriptions'];
     $request = $link->query("UPDATE modelo SET marca_id='".$brand_id."', modelo_nombre='".$models_name."', modelo_descripcion='".$models_descriptions."' WHERE modelo_id='".$model_id."';");
    if($request){
      ?>
      <div class="alert alert-success alert-dismissible" role="alert">
         <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
         <strong>MODELO ACTUALIZADO EXITOSAMENTE.</strong>
      </div>
      <script>
        selects_models();
        $("#modal_edits_models").modal('hide');
      </script>
      <?php
    }
  }
}
?>