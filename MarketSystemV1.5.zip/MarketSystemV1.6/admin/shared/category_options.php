<?php
session_start();
include('../database.php');
if($_POST){
$options  =$_POST['options'];
  if($options=="SELECT"){
    include("category_list.php");
  }
  if($options=="SAVED"){
    $category_name          = $_POST['category_name'];
    $category_description   = $_POST['category_description'];
     $request = $link->query("INSERT INTO categorias (categoria_nombre, categoria_descripcion) VALUES ('".$category_name."', '".$category_description."');");
    if($request){
      ?>
            <div class="alert alert-success alert-dismissible" role="alert">
              <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
              <strong>CATEGORIA CREADA EXITOSAMENTE.</strong>
            </div>
       <script>
            selects_category();
            $("#modal_details").modal('hide');
      </script>
      <?php
    }
  }
  if($options=="DELETE"){
    $category_id  =$_POST['category_id'];
    $request = $link->query("DELETE FROM categorias WHERE categoria_id='".$category_id."' LIMIT 1;");
    if($request){
       ?> 
        <div class="alert alert-success alert-dismissible" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <strong>CATEGORIA ELIMINADA!</strong> EXITOSAMENTE.
         </div>
       <script>
           selects_category();
      </script>
      <?php
    }
  }
  if($options=="EDITS_CONTROLS"){
      $category_id  =$_POST['category_id'];
      $data = $link->query("SELECT categoria_id, categoria_nombre, categoria_descripcion FROM categorias WHERE categoria_id='".$category_id."';");
      $request = $data->fetch_array(MYSQLI_ASSOC);
      $category_name = $request['categoria_nombre'];
      $category_description = $request['categoria_descripcion'];
    ?>
    <H4>EDITAR DATOS DE CATEGORIA</H4>
    <div class="row">
     <div class="col-md-12">
     <form>
        <div class="form-group">
           <label for="user_name">NOMBRE:</label>
             <input type="text" class="form-control" id="edit_category_name" value="<?=$category_name;?>" required>
        </div>
         <div class="form-group">
          <label for="user_full_name">DESCRIPCION</label>
          <input type="text" class="form-control" id="edit_category_description" value="<?=$category_description;?>" required>
        </div>
        <hr>
        <input type="hidden" id="edits_category_id" value="<?=$category_id;?>" />
        <div class="row">
          <div class="col-md-12 text-center">
          <div class="btn-group" role="group" aria-label="options_buttons">
            <button type="button" class="btn btn-danger" data-dismiss="modal" style="width:150px;">SALIR</button>
            <button type="button" class="btn btn-success" style="width:150px;" onclick="edits_categories();">GUARDAR CAMBIOS</button>
          </div>
          </div>
        </div>
      </form>
     </div>
     </div>
  <?php
  }
  if($options=="EDITS"){
    $category_id       =$_POST['category_id'];
    $category_name      =$_POST['category_name'];
    $category_descriptions =$_POST['category_descriptions'];
     $request = $link->query("UPDATE categorias SET categoria_nombre='".$category_name."', categoria_descripcion='".$category_descriptions."' WHERE categoria_id='".$category_id."';");
    if($request){
      ?>
            <div class="alert alert-success alert-dismissible" role="alert">
              <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
              <strong>CATEGORIA ACTUALIZADA EXITOSAMENTE.</strong>
            </div>
       <script>
            selects_category();
            $("#modal_edits_category").modal('hide');
      </script>
      <?php
    }
  }
}
?>