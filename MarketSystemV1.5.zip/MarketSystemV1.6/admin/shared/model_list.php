<table id="lists_datatable" class="table table-hover table-bordered text-center">
 <thead style="text-align:center;font-weight:bold;">
  <tr class="info">
    <td>#</td>
    <td>CODIGO</td>
    <td>NOMBRE MARCA</td>
    <td>NOMBRE MODELO</td>
    <td>DESCRIPCION</td>
    <td>ACCIONES</td>
  </tr>
 </thead>
 <tbody>
  <?php
  $data = $link->query("SELECT modelo.modelo_id AS 'id', marca.marca_nombre AS 'nombre_marca',modelo.modelo_nombre AS 'nombre_modelo', modelo.modelo_descripcion AS 'descripcion' FROM modelo LEFT JOIN marca on (marca.marca_id = modelo.marca_id);");
  $n=0;
  while($data_brand = $data->fetch_assoc()){
    $models_id            = $data_brand['id'];
    $brand_name           = $data_brand['nombre_marca'];
    $models_name          = $data_brand['nombre_modelo'];
    $models_description   = $data_brand['descripcion'];
    $data_ckeck         = $link->query("SELECT COUNT(producto_id) AS 'count' FROM productos WHERE modelo_id='".$models_id."';");
    $request_check    = $data_ckeck->fetch_array(MYSQLI_ASSOC);
    $check_count      = $request_check['count'];
    $n++;
    ?>
    <tr>
      <td><?=$n;?></td>
      <td><?=$models_id;?></td>
      <td><?=$brand_name;?></td>
      <td><?=$models_name;?></td>
      <td><?=$models_description;?></td>
      <td style="text-align:center;">
        <div class="btn-group" role="group" aria-label="...">
           <button type="button" class="btn btn-info" onclick="edits_models(<?=$models_id;?>);" data-toggle="modal" data-target="#modal_edits_models_" data-backdrop="static">
              <span class="glyphicon glyphicon-pencil" aria-hidden="true"></span>
          </button>
        <?php
            if($check_count>0){
            ?>
              <button type="button" class="btn btn-danger" disabled>
              <span class="glyphicon glyphicon-trash" aria-hidden="true"></span>
              </button>
            <?php
            }else{
            ?>
              <button type="button" class="btn btn-danger" onclick="delete_models('<?=$models_id;?>', '1');">
              <span class="glyphicon glyphicon-trash" aria-hidden="true"></span>
              </button>
            <?php
            }
          ?>
        </div>
      </td>
    </tr>
    <?php
  }//https://www.mediafire.com/folder/gz9a0vptbz5mk//Full%20Metal%20Alchemist%20%5BNura%5D
  ?>
 </tbody>
</table>