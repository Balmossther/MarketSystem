<table id="lists_datatable" class="table table-hover table-bordered text-center">
     <thead style="text-align:center;font-weight:bold;">
      <tr class="info">
        <td>#</td>
        <td>NOMBRE</td>
        <td>USUARIO</td>
        <td>CLAVE</td>
        <td>TIPO</td>
        <td>FECHA REGISTRO</td>
        <td>ESTADO</td>
        <td>ACCIONES</td>
      </tr>
     </thead>
     <tbody>
      <?php
      $data = $link->query("SELECT * FROM usuarios;");
      $n=0;
      while($data_users = $data->fetch_assoc()){
        $user_id= $data_users['usuario_id'];
        $name   = $data_users['usuario_nombre'];
        $users  = $data_users['usuario_user'];
        $passw  = $data_users['usuario_passw'];
        $type   = $data_users['usuario_tipo'];
        $status = $data_users['usuario_estado'];
        $date   = $data_users['usuario_fecha_registro'];
        $n++;
        ?>
        <tr>
          <td style="text-align:center;"><?=$n;?></td>
          <td style="text-align:center;"><?=$name;?></td>
          <td style="text-align:center;"><?=$users;?></td>
          <?php
          if(strtolower($_SESSION["usuario"])==strtolower($users)){
            ?>
            <td style="text-align:center;"><?=$passw;?></td>
            <?php
          }else{
            ?>
            <td style="text-align:center;">******</td>
            <?php
          }
          ?>
          <td style="text-align:center;"><?=$type;?></td>
          <td style="text-align:center;"><?=$date;?></td>
          <td style="text-align:center;"><?=$status;?></td>
          <td style="text-align:center;">
            <div class="btn-group" role="group" aria-label="...">
              <button type="button" class="btn btn-info" onclick="edits_user(<?=$user_id;?>);" data-toggle="modal" data-target="#modal_edits_users" data-backdrop="static">
              <span class="glyphicon glyphicon-pencil" aria-hidden="true"></span>
              </button>
              <button type="button" class="btn btn-danger" onclick="delete_users('<?=$user_id;?>', '1');">
              <span class="glyphicon glyphicon-trash" aria-hidden="true"></span>
              </button>
            </div>
          </td>
        </tr>
        <?php
      }
      ?>
     </tbody>
    </table>