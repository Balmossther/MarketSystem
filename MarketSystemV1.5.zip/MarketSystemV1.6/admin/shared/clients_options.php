<?php
session_start();
date_default_timezone_set('America/El_Salvador');
include('../database.php');
if($_POST){
$options  =$_POST['options'];
  if($options=="SELECT"){
    include("clients_list.php");
  }
  if($options=="SAVED"){
    $clients_name           =$_POST['clients_name'];
    $clients_last_name      =$_POST['clients_last_name'];
    $clients_passwd         =$_POST['clients_passwd'];
    $clients_email          =$_POST['clients_email'];
    $clients_cellphone      =$_POST['clients_cellphone'];
    $clients_date_borth     =$_POST['clients_date_borth'];
    $clients_address        =$_POST['clients_address'];
    $clients_country        =$_POST['clients_country'];
    $clients_departaments   =$_POST['clients_departaments'];
    $date_time              = date("YmdHis");
    $q="INSERT INTO clientes (cliente_nombre, cliente_apellido, cliente_correo, cliente_passw, cliente_pais, cliente_departamento, cliente_direccion, cliente_telefono, cliente_fecha_registro, cliente_fecha_nacimiento) VALUES ('".$clients_name."', '".$clients_last_name."', '".$clients_email."', '".$clients_passwd."', '".$clients_country."', '".$clients_departaments."', '".$clients_address."', '".$clients_cellphone."', '".$date_time."', '".$clients_date_borth."');";
     $request = $link->query($q);
    if($request){
      ?>
            <div class="alert alert-success alert-dismissible" role="alert">
              <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
              <strong>CLIENTE REGISTRADO EXITOSAMENTE.</strong>
            </div>
       <script>
            selects_clients();
            $("#modal_details").modal('hide');
      </script>
      <?php
    }
  }
  if($options=="DELETE"){
  $clients_id  =$_POST['clients_id'];
    $request = $link->query("DELETE FROM clientes WHERE cliente_id='".$clients_id."';");
    if($request){
       ?> 
        <div class="alert alert-success alert-dismissible" role="alert">
              <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
              <strong>ELIMINADO!</strong> CLIENTE ELIMINADO EXITOSAMENTE.
         </div>
       <script>
           selects_clients();
      </script>
      <?php
    }
  }
  if($options=="EDITS_CONTROLS"){
      $clients_id  =$_POST['clients_id'];
      $data = $link->query("SELECT cliente_nombre, cliente_apellido, cliente_correo, cliente_passw, cliente_pais, cliente_departamento, cliente_direccion, cliente_telefono, cliente_fecha_nacimiento FROM clientes WHERE cliente_id='".$clients_id."';");
      $request = $data->fetch_array(MYSQLI_ASSOC);
      $name = $request['cliente_nombre'];
      $lastnamer = $request['cliente_apellido'];
      $email = $request['cliente_correo'];
      $passw = $request['cliente_passw'];
      $country = $request['cliente_pais'];
      $departaments = $request['cliente_departamento'];
      $address = $request['cliente_direccion'];
      $cellphone = $request['cliente_telefono'];
      $date_borth = $request['cliente_fecha_nacimiento'];
    ?>
    <H4>EDITAR DATOS DE CLIENTE</H4>
    <div class="row">
     <div class="col-md-12">
     <form>
        <div class="form-group">
                  <label for="user_name">NOMBRE:</label>
                  <input type="text" class="form-control" id="edits_clients_name" value="<?=$name;?>">
                </div>
                <div class="form-group">
                  <label for="user_full_name">APELLIDO:</label>
                  <input type="text" class="form-control" id="edits_clients_last_name" value="<?=$lastnamer;?>" required>
                </div>
                 <div class="form-group">
                  <label for="passwd">CONTRASEÑA:</label>
                  <input type="password" class="form-control" id="edits_clients_passwd" value="<?=$passw;?>">
                </div>
                <div class="form-group">
                  <label for="email">CORREO:</label>
                  <input type="text" class="form-control" id="edits_clients_email" value="<?=$email;?>">
                </div>
                <div class="form-group">
                  <label for="email">TELEFONO:</label>
                  <input type="text" class="form-control" id="edits_clients_cellphone" value="<?=$cellphone;?>">
                </div>
                 <div class="form-group">
                  <label for="email">FECHA DE NACIMIENTO:</label>
                  <input type="datetime" id='edits_clients_date_borth' name='edits_clients_date_borth' value="<?=$date_borth;?>" class="form-control"  style="width:125px;text-align:center;cursor:pointer;">
                  <script type="text/javascript">
                    //$( "#edits_clients_date_borth" ).datepicker({  maxDate: 0 });
                  </script>
                </div>
                 <div class="form-group">
                  <label for="email">DIRECCION:</label>
                  <textarea class="form-control" id="edits_clients_address" style="resize:none;"><?=$address;?></textarea>
                </div>
                 <div class="form-group">
                  <label for="user_type">PAIS:</label>
                  <select class="form-control" name="edits_clients_country" id="edits_clients_country">
                  <option value="EL SALVADOR">EL SALVADOR</option>
                  <!--<option value="GUATEMALA">GUATEMALA</option>
                  <option value="HONDURAS">HONDURAS</option>
                  <option value="NICARAGUA">NICARAGUA</option>
                  <option value="COSTA RICA">COSTA RICA</option>
                  <option value="BELICE">BELICE</option>
                  <option value="PANAMA">PANAMA</option>-->
                  </select>
                </div>
                 <div class="form-group">
                  <label for="user_type">DEPARTAMENTO:</label>
                  <select class="form-control" name="edits_clients_departaments" id="edits_clients_departaments">
                  <option value="SAN SALVADOR">SAN SALVADOR</option>
                  <option value="SAN MIGUEL">SAN MIGUEL</option>
                  <option value="LA UNION">LA UNION</option>
                  <option value="MORAZAN">MORAZAN</option>
                  <option value="USULUTAN">USULUTAN</option>
                  </select>
                </div>
        <hr>
        <input type="hidden" id="edits_clients_id" value="<?=$clients_id;?>" />
        <div class="row">
          <div class="col-md-12 text-center">
          <div class="btn-group" role="group" aria-label="options_buttons">
            <button type="button" class="btn btn-danger" data-dismiss="modal" style="width:150px;">SALIR</button>
            <button type="button" class="btn btn-success" style="width:150px;" onclick="edit_saved_clients();">GUARDAR CAMBIOS</button>
          </div>
          </div>
        </div>
      </form>
     </div>
     </div>
  <?php
  }
  if($options=="EDITS"){
    $clients_id             =$_POST['clients_id'];
    $clients_name           =$_POST['clients_name'];
    $clients_last_name      =$_POST['clients_last_name'];
    $clients_passwd         =$_POST['clients_passwd'];
    $clients_email          =$_POST['clients_email'];
    $clients_cellphone      =$_POST['clients_cellphone'];
    $clients_date_borth     =$_POST['clients_date_borth'];
    $clients_address        =$_POST['clients_address'];
    $clients_country        =$_POST['clients_country'];
    $clients_departaments   =$_POST['clients_departaments'];
     $request = $link->query("UPDATE clientes SET cliente_nombre='".$clients_name."', cliente_apellido='".$clients_last_name."', cliente_passw='".$clients_passwd."', cliente_correo='".$clients_email."', cliente_pais='".$clients_country."', cliente_departamento='".$clients_departaments."', cliente_direccion='".$clients_address."', cliente_telefono='".$clients_cellphone."', cliente_fecha_nacimiento='".$clients_date_borth."' WHERE cliente_id='".$clients_id."';");
    if($request){
      ?>
            <div class="alert alert-success alert-dismissible" role="alert">
              <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
              <strong>CLIENTE ACTUALIZADO EXITOSAMENTE.</strong>
            </div>
       <script>
            selects_clients();
            $("#modal_edits_clients").modal('hide');
      </script>
      <?php
    }
  }
}
?>