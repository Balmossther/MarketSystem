<?php
session_start();
if(!isset($_SESSION["usuario"])){
?>
<script type="text/javascript">
  window.location="login.php";
</script>
<?php
}
?>
<!DOCTYPE html>
<html lang="es">
  <head>
   <?php include("includes/header.php");?>
  </head>
  <body>
  <?php
  include('database.php');
  include('menu.php');
  ?>
  <div class="container">
    <h1>Administracion Tienda</h1>
    <br>
    <div class="row">
		<div class="col-md-12 col-sm-12 col-xs-12">
          <div class="panel panel-info text-center">
            <div class="panel-heading"><b>ULTIMOS PEDIDOS</b></div>
              <div class="panel-body">
                <div class="row">
                  <div class="col-md-3">
                      <a href="ventas_admin.php"><i class="fa fa-cart-arrow-down" aria-hidden="true" style="font-size:125px;margin:0 auto;"></i></a>
                  </div>
                  <div class="col-md-9">
                      <h5>ULTIMOS <b>3 PEDIDOS</b> REGISTRADOS</h5>
                      <div class="panel panel-default">
                      <div class="panel-body">
                          <table class="table" style="font-size:11px;">
                           <tr style="font-weight:bold;">
                          <td>CODIGO DE VENTA</td>
                          <td>CLIENTE</td>
                          <td>CANTIDAD</td>
                          <td>TOTAL</td>
                          <td>ESTADO</td>
                          </tr>
                          <?php
                            $data = $link->query("SELECT venta_id, cliente_nombre, cliente_apellido, venta_cantidad, venta_total, venta_estado FROM ventas_general INNER JOIN clientes ON (clientes.cliente_id=ventas_general.cliente_id) ORDER BY venta_fecha DESC LIMIT 3;");
                            $n=0;
                            while($data_sales  = $data->fetch_assoc()){
                            $sales_id           = $data_sales['venta_id'];
                            $clients_name       = $data_sales['cliente_nombre'];
                            $clients_lastname   = $data_sales['cliente_apellido'];
                            $sales_quantity     = $data_sales['venta_cantidad'];
                            $sales_total        = $data_sales['venta_total'];
                            $sales_status       = $data_sales['venta_estado'];
                            $sales_total        = number_format(($sales_total), 2, '.', '');
                            $n++;
                            
                            ?>
                              <tr>
                              <td><?=$sales_id;?></td>
                              <td><?=$clients_name;?> <?=$clients_lastname;?></td>
                              <td><?=$sales_quantity;?></td>
                              <td>$ <?=$sales_total;?></td>
                              <td><?=$sales_status;?></td>
                              </tr>
                            <?php
                          }
                          ?>
                         </table>
                      </div>
                    </div>
                  </div>
                </div>
            </div>
          </div>
        </div>
	</div>
    <div class="row">
        <div class="col-md-6 col-sm-6 col-xs-6">
          <div class="panel panel-info text-center">
            <div class="panel-heading"><b>ADMON. USUARIOS</b></div>
              <div class="panel-body">
                <div class="row">
                  <div class="col-md-3">
                      <a href="usuarios_admin.php"><i class="fa fa-users" aria-hidden="true" style="font-size:125px;margin:0 auto;"></i></a>
                  </div>
                  <div class="col-md-9">
                      <h5>ULTIMOS <b>3 USUARIOS</b> REGISTRADOS</h5>
                      <div class="panel panel-default">
                      <div class="panel-body">
                          <table class="table" style="font-size:11px;">
                           <tr style="font-weight:bold;">
                          <td>NOMBRE</td>
                          <td>USUARIO</td>
                          <td>TIPO</td>
                          </tr>
                          <?php
                          $data = $link->query("SELECT * FROM usuarios ORDER BY usuario_fecha_registro DESC LIMIT 3;");
                          $n=0;
                          while($data_users = $data->fetch_assoc()){
                            $user_id= $data_users['usuario_id'];
                            $name   = $data_users['usuario_nombre'];
                            $users  = $data_users['usuario_user'];
                            $passw  = $data_users['usuario_passw'];
                            $type   = $data_users['usuario_tipo'];
                            $status = $data_users['usuario_estado'];
                            $date   = $data_users['usuario_fecha_registro'];
                            $n++;
                            ?>
                              <tr>
                              <td><?=$name;?></td>
                              <td><?=$users;?></td>
                              <td><?=$type;?></td>
                              </tr>
                            <?php
                          }
                          ?>
                         </table>
                      </div>
                    </div>
                  </div>
                </div>
            </div>
          </div>
        </div>
		<div class="col-md-6 col-sm-6 col-xs-6">
          <div class="panel panel-info text-center">
            <div class="panel-heading"><b>EXISTENCIAS - PRODUCTOS</b></div>
              <div class="panel-body">
                <div class="row">
                  <div class="col-md-3">
                      <a href="producto_admin.php"><i class="fa fa-sort-amount-asc" aria-hidden="true" style="font-size:125px;margin:0 auto;"></i></a>
                  </div>
                  <div class="col-md-9">
                      <h5>LOS <b> 3 PRODUCTOS</b> CON MENOS EXISTENCIA</h5>
                      <div class="panel panel-default">
                      <div class="panel-body">
                          <table class="table" style="font-size:11px;">
                           <tr style="font-weight:bold;">
                          <td>NOMBRE</td>
                          <td>DESCRIPCION</td>
                          <td>EXISTENCIAS</td>
                          </tr>
                          <?php
                            $data = $link->query("SELECT productos.producto_id AS 'id', categorias.categoria_nombre AS 'category_name', modelo.modelo_nombre AS 'model_name', marca.marca_nombre AS 'brand_name', productos.producto_nombre AS 'product_name', productos.producto_descripcion AS 'product_description', productos.producto_precio AS 'product_price', productos.producto_cantidad AS 'product_quantity', productos.producto_fecha_registro AS 'product_date_registed' FROM productos INNER JOIN categorias ON (categorias.categoria_id=productos.categoria_id) INNER JOIN modelo ON (modelo.modelo_id=productos.modelo_id) INNER JOIN marca ON (marca.marca_id=productos.marca_id) ORDER BY productos.producto_cantidad ASC LIMIT 3;");
                            $n=0;
                            while($data_products  = $data->fetch_assoc()){
                            $product_id         = $data_products['id'];
                            $category_name      = $data_products['category_name'];
                            $model_name         = $data_products['model_name'];
                            $brand_name         = $data_products['brand_name'];
                            $product_name       = $data_products['product_name'];
                            $product_description= $data_products['product_description'];
                            $product_price      = $data_products['product_price'];
                            $product_quantity   = $data_products['product_quantity'];
                            $product_date_registed = $data_products['product_date_registed'];
                            $product_price_total   = number_format(($product_quantity*$product_price), 2, '.', '');
                            $n++;
                            ?>
                              <tr>
                              <td><?=$product_name;?></td>
                              <td><?=$product_description;?></td>
                              <td><?=$product_quantity;?></td>
                              </tr>
                            <?php
                          }
                          ?>
                         </table>
                      </div>
                    </div>
                  </div>
                </div>
            </div>
          </div>
        </div>
    </div>
	<div class="row">
		<div class="col-md-12 col-sm-12 col-xs-12">
          <div class="panel panel-info text-center">
            <div class="panel-heading"><b>ADMON. DE PRODUCTOS</b></div>
              <div class="panel-body">
                <div class="row">
                  <div class="col-md-3">
                      <a href="producto_admin.php"><i class="fa fa-server" aria-hidden="true" style="font-size:125px;margin:0 auto;"></i></a>
                  </div>
                  <div class="col-md-9">
                      <h5>ULTIMOS <b>3 PRODUCTOS</b> REGISTRADOS</h5>
                      <div class="panel panel-default">
                      <div class="panel-body">
                          <table class="table" style="font-size:11px;">
                           <tr style="font-weight:bold;">
                          <td>NOMBRE</td>
                          <td>DESCRIPCION</td>
                          <td>PRECIO</td>
                          <td>EXISTENCIAS</td>
                          <td>TOTAL</td>
                          </tr>
                          <?php
                            $data = $link->query("SELECT productos.producto_id AS 'id', categorias.categoria_nombre AS 'category_name', modelo.modelo_nombre AS 'model_name', marca.marca_nombre AS 'brand_name', productos.producto_nombre AS 'product_name', productos.producto_descripcion AS 'product_description', productos.producto_precio AS 'product_price', productos.producto_cantidad AS 'product_quantity', productos.producto_fecha_registro AS 'product_date_registed' FROM productos INNER JOIN categorias ON (categorias.categoria_id=productos.categoria_id) INNER JOIN modelo ON (modelo.modelo_id=productos.modelo_id) INNER JOIN marca ON (marca.marca_id=productos.marca_id) ORDER BY productos.producto_fecha_registro DESC LIMIT 3;");
                            $n=0;
                            while($data_products  = $data->fetch_assoc()){
                            $product_id         = $data_products['id'];
                            $category_name      = $data_products['category_name'];
                            $model_name         = $data_products['model_name'];
                            $brand_name         = $data_products['brand_name'];
                            $product_name       = $data_products['product_name'];
                            $product_description= $data_products['product_description'];
                            $product_price      = $data_products['product_price'];
                            $product_quantity   = $data_products['product_quantity'];
                            $product_date_registed = $data_products['product_date_registed'];
                            $product_price_total   = number_format(($product_quantity*$product_price), 2, '.', '');
                            $n++;
                            ?>
                              <tr>
                              <td><?=$product_name;?></td>
                              <td><?=$product_description;?></td>
                              <td>$ <?=$product_price;?></td>
                              <td><?=$product_quantity;?></td>
                              <td>$ <?=$product_price_total;?></td>
                              </tr>
                            <?php
                          }
                          ?>
                         </table>
                      </div>
                    </div>
                  </div>
                </div>
            </div>
          </div>
        </div>
	</div>
  </div>
<?php include("includes/footer.php");?>
  </body>
</html>