<!DOCTYPE html>
<html lang="en">
  <head>
    <?php include("includes/header.php");?>
  <style>
    /* Permalink - use to edit and share this gradient: http://colorzilla.com/gradient-editor/#7d7e7d+0,0e0e0e+100;Black+3D */
    body{
    /* Permalink - use to edit and share this gradient: http://colorzilla.com/gradient-editor/#7d7e7d+0,0e0e0e+100;Black+3D */
    background: #7d7e7d; /* Old browsers */
    background: -moz-linear-gradient(left,  #7d7e7d 0%, #0e0e0e 100%); /* FF3.6-15 */
    background: -webkit-linear-gradient(left,  #7d7e7d 0%,#0e0e0e 100%); /* Chrome10-25,Safari5.1-6 */
    background: linear-gradient(to right,  #7d7e7d 0%,#0e0e0e 100%); /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
    filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#7d7e7d', endColorstr='#0e0e0e',GradientType=1 ); /* IE6-9 */
    }
  </style>
  </head>
  <body>
  <div class="container">
  <br>
  <br>
  <br>
  <br>
    <div class="row vertical-offset-100">
      <div class="col-md-4 col-md-offset-4">
        <div class="panel panel-default">
          <div class="panel-heading">
            <h3 class="panel-title">TIENDA ONLINE</h3>
        </div>
        <br>
          <div class="panel-body">
            <form accept-charset="UTF-8" role="form">
              <fieldset>
                <div class="form-group">
                  <input class="form-control" placeholder="USUARIO" id="username" name="username" type="text">
              </div>
              <div class="form-group">
                <input class="form-control" placeholder="CONTRASE&Ntilde;A" id="password" name="password" type="password" value="">
              </div>
              <br>
              <input class="btn btn-lg btn-success btn-block" type="button"  onclick="sendlogin();" value="INGRESAR">
              </fieldset>
              <br>
            </form>
          </div>
       </div>
      </div>
    </div>
   <div id="mini_request"></div>
  </div>
  <?php include("includes/footer.php");?>
  </body>
</html>