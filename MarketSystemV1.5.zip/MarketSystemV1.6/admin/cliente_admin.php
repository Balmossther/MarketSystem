<?php
session_start();
if(isset($_SESSION["usuario"])){
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <?php include("includes/header.php");?>
    <style>
        #ui-datepicker-div{ z-index: 1000; } 
    </style>
  </head>
  <body>
  <?php
  include('database.php');
  include('menu.php');
  ?>
  <div class="container" style="width:98%;">
    <h2>
    <i class="fa fa-users" aria-hidden="true"></i>
    ADMINISTRACION DE CLIENTES
    </h2>
    <div class="row">
      <div class="col-md-9">
        <div id="mini_request_clients"></div>
      </div>
      <div class="col-md-3 text-right">
        <button type="button" class="btn btn-success btn-md" data-toggle="modal" data-target="#modal_details" data-backdrop="static">
          <span class="glyphicon glyphicon-plus" aria-hidden="true"></span> REGISTRAR NUEVO CLIENTE
        </button>
      </div>
    </div>
    <br>
    <div id="request_list">
    <?php include("shared/clients_list.php");?>  
    </div>
   </div>
   <div class="modal fade" id="modal_details" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-md">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
          </div>
          <div class="modal-body">
            <div id="report_data_details">
            <H4>NUEVO CLIENTE</H4>
             <div class="row">
             <div class="col-md-12">
             <form>
                <div class="form-group">
                  <label for="user_name">NOMBRE:</label>
                  <input type="text" class="form-control" id="clients_name" required>
                </div>
                <div class="form-group">
                  <label for="user_full_name">APELLIDO:</label>
                  <input type="text" class="form-control" id="clients_last_name" required>
                </div>
                 <div class="form-group">
                  <label for="passwd">CONTRASEÑA:</label>
                  <input type="password" class="form-control" id="clients_passwd" required>
                </div>
                <div class="form-group">
                  <label for="email">CORREO:</label>
                  <input type="text" class="form-control" id="clients_email" required>
                </div>
                <div class="form-group">
                  <label for="email">TELEFONO:</label>
                  <input type="text" class="form-control" id="clients_cellphone" required>
                </div>
                 <div class="form-group">
                  <label for="email">FECHA DE NACIMIENTO:</label>
                  <input type="datetime" id='clients_date_borth' name='clients_date_borth' class="form-control"  style="width:125px;text-align:center;cursor:pointer;" >
                  <script type="text/javascript">
                    //$( "#clients_date_borth" ).datepicker({  maxDate: 0 });
                  </script>
                </div>
                 <div class="form-group">
                  <label for="email">DIRECCION:</label>
                  <textarea class="form-control" id="clients_address" style="resize:none;"></textarea>
                </div>
                 <div class="form-group">
                  <label for="user_type">PAIS:</label>
                  <select class="form-control" name="clients_country" id="clients_country">
                  <option value="EL SALVADOR">EL SALVADOR</option>
                  <!--<option value="GUATEMALA">GUATEMALA</option>
                  <option value="HONDURAS">HONDURAS</option>
                  <option value="NICARAGUA">NICARAGUA</option>
                  <option value="COSTA RICA">COSTA RICA</option>
                  <option value="BELICE">BELICE</option>
                  <option value="PANAMA">PANAMA</option>-->
                  </select>
                </div>
                 <div class="form-group">
                  <label for="user_type">DEPARTAMENTO:</label>
                  <select class="form-control" name="clients_departaments" id="clients_departaments">
                  <option value="SAN SALVADOR">SAN SALVADOR</option>
                  <option value="SAN MIGUEL">SAN MIGUEL</option>
                  <option value="LA UNION">LA UNION</option>
                  <option value="MORAZAN">MORAZAN</option>
                  <option value="USULUTAN">USULUTAN</option>
                  </select>
                </div>
                <hr>
                <div class="row">
                  <div class="col-md-12 text-center">
                  <div class="btn-group" role="group" aria-label="options_buttons">
                    <button type="button" class="btn btn-danger" data-dismiss="modal" style="width:150px;">SALIR</button>
                    <button type="button" class="btn btn-success" style="width:150px;" onclick="saved_new_clients();">GUARDAR DATOS</button>
                  </div>
                  </div>
                </div>
              </form>
             </div>
             </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="modal fade" id="modal_edits_clients" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-md">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
          </div>
          <div class="modal-body">
            <div id="report_data_edits_client">
            </div>
          </div>
        </div>
      </div>
    </div>
   <footer>
     <?php include("includes/footer.php");?>
   </footer>
  </body>
</html>
<?php } ?>