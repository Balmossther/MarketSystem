
   <style type="text/css" title="currentStyle">
     
      @import "css/table_table_jui.css";
   
    </style>
  <link rel="stylesheet" media="all" type="text/css" href="css/jquery-ui.css" />
<script type="text/javascript" src="js/jquery-ui.min.js"></script>

    <script type="text/javascript" language="javascript" src="js/jquery.dataTables.js"></script>
    <script type="text/javascript" charset="utf-8">
      $(document).ready(function() {
        $('#listados').dataTable( {
          "iDisplayLength": 100,
             "aLengthMenu": [50, 100,150, 100, ,200, 500, 1000],
          "bJQueryUI": true,
          "bAutoWidth": false,
          "sPaginationType": "full_numbers"
        } );
      } );

      </script>
	  
	  
	  
	  