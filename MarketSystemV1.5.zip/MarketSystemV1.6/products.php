 <?php
session_start();
include('includes/database.php');
?>
<!DOCTYPE html>
<html>
<head>
  <?php include("includes/header.php");?>
</head>
<body>
<?php 
include("pages/shared/menu.php"); 
?>
<div class="container">
    <div class="row">
        <div class="col-md-4">
        <?php include('pages/brand_list.php'); ?>
        </div>
        <div class="col-md-8"> 
        <?php 
         include('pages/product_registed.php');
        ?>
        </div>
    </div>
</div>
</body>
</html>