$(document).ready(function(){
});
function login_clients(){
    var options = "login";
    var users = $("#login_user").val();
    var passsw = $("#login_passwd").val();
    var data_send = {
                "options" : options,
                "username" : users,
                "passsw" : passsw
     }
    $.ajax({
                data:  data_send,
                url:   'pages/process_clients_data.php',
                type:  'post',
                beforeSend: function () {
                    $("#mini_request_header").html("<script>console.log('verificando');</script>");
                },
                success:  function (response) {
                    $("#mini_request_header").html(response);
                }
          });
}
function login_close_clients(){
    var options = "closing";
    var data_send = { "options" : options }
    $.ajax({
                data:  data_send,
                url:   'pages/process_clients_data.php',
                type:  'post',
                beforeSend: function () {
                    $("#mini_request_header").html("<script>console.log('verificando');</script>");
                },
                success:  function (response) {
                    $("#mini_request_header").html(response);
                }
          });
}
function saved_new_clients(){
    var clients_name            = $("#clients_name").val();
    var clients_last_name       = $("#clients_last_name").val();
    var clients_passwd          = $("#clients_passwd").val();
    var clients_email           = $("#clients_email").val();
    var clients_cellphone       = $("#clients_cellphone").val();
    var clients_date_borth      = $("#clients_date_borth").val();
    var clients_address         = $("#clients_address").val();
    var clients_country         = $('select[name=clients_country]').val();
    var clients_departaments    = $('select[name=clients_departaments]').val();
    var options                 = "saved_new_clients";
    if($.trim(clients_name)==""){ $("#clients_name").css("border", "1px solid red"); $("#clients_name").focus(); return;  }
    if($.trim(clients_last_name)==""){ $("#clients_last_name").css("border", "1px solid red"); $("#clients_last_name").focus(); return;  }
        var data_send = {
                "clients_name" : clients_name,
                "clients_last_name" : clients_last_name,
                "clients_passwd" : clients_passwd,
                "clients_email" : clients_email,
                "clients_cellphone" : clients_cellphone,
                "clients_date_borth" : clients_date_borth,
                "clients_address" : clients_address,
                "clients_country" : clients_country,
                "clients_departaments" : clients_departaments,
                "options" : options
        }
        $.ajax({
                data:  data_send,
                url:   'pages/process_clients_data.php',
                type:  'post',
                beforeSend: function () {
                    $("#mini_request_header").html("<script>console.log('verificando');</script>");
                },
                success:  function (response) {
                    $("#mini_request_header").html(response);
                }
        }); 
}
function products_add_list(product_id){
    var clients_online  = $("#clients_id_online").val();
    var options         = "add_list";
    if(clients_online>0){
        var data_send = {
            "clients_online" : clients_online,
            "product_id" : product_id,
            "options" : options
        }
        $.ajax({
                data:  data_send,
                url:   'pages/process_products_data.php',
                type:  'post',
                beforeSend: function () {
                    $("#mini_request_header").html("<script>console.log('verificando');</script>");
                },
                success:  function (response) {
                    $("#mini_request_header").html(response);
                }
        }); 
    }else{
        alert("EL CLIENTE DEBE DE INICIAR SESION!");
    }
}
function view_list_cars(){
    var clients_online  = $("#clients_id_online").val();
    var options         = "view_list";
    var data_send = {
            "clients_online" : clients_online,
            "options" : options
        }
        $.ajax({
                data:  data_send,
                url:   'pages/process_products_data.php',
                type:  'post',
                beforeSend: function () {
                    $("#id_lista_carrito").html("<script>console.log('verificando');</script>");
                },
                success:  function (response) {
                    $("#id_lista_carrito").html(response);
                }
        });
}
function search_products(){
    var search = $("#text_search_products").val();
    if(search!=""){
        window.location="products.php?options=search&search="+search;
    }
}
function products_details(product_id){
    var options = "details";
    var pparameters = {
            "options"   : options, 
            "product_id": product_id
        }
    var url = "products_details.php";
    redirect_by_post(url, pparameters, false);
}
function redirect_by_post(purl, pparameters, in_new_tab) {
  pparameters = (typeof pparameters == 'undefined') ? {} : pparameters;
  in_new_tab = (typeof in_new_tab == 'undefined') ? true : in_new_tab;
  var form = document.createElement("form");
  $(form).attr("id", "reg-form").attr("name", "reg-form").attr("action", purl).attr("method", "post").attr("enctype", "multipart/form-data");
  if (in_new_tab) {
      $(form).attr("target", "_blank");
  }
  $.each(pparameters, function(key) {
      $(form).append('<input type="text" name="' + key + '" value="' + this + '" />');
  });
  document.body.appendChild(form);
  form.submit();
  document.body.removeChild(form);
  return false;
} 
function products_delete(product_id, clients_id){
    var options         = "delete_product_list";
    var data_send = {
            "clients_online" : clients_id,
            "product_id" : product_id,
            "options" : options
        }
        $.ajax({
                data:  data_send,
                url:   'pages/process_products_data.php',
                type:  'post',
                beforeSend: function () {
                    $("#id_lista_carrito").html("<script>console.log('verificando');</script>");
                },
                success:  function (response) {
                    $("#id_lista_carrito").html(response);
                }
        });
}
function send_process_before_invoices(){
   var clients_online  = $("#clients_id_online").val();
   var options         = "previous_invoice";
   var pparameters = {
            "options"   : options, 
            "clients_online": clients_online
        }
   var url = "products_process.php";
   redirect_by_post(url, pparameters, false);
}
function send_process_invoice(){
   var clients_online  = $("#clients_id_online").val();
   var options         = "process_invoice";
    var data_send = {
            "clients_online" : clients_online,
            "options" : options
        }
        $.ajax({
                data:  data_send,
                url:   'pages/process_products_data.php',
                type:  'post',
                beforeSend: function () {
                    $("#mini_request_order").html("<script>console.log('verificando');</script>");
                },
                success:  function (response) {
                    $("#mini_request_order").html(response);
                }
        });
}
function send_process_invoice_print(){
   var clients_online  = $("#clients_id_online").val();
   var options         = "print_invoice";
   var pparameters = {
            "options"   : options, 
            "clients_online": clients_online
        }
   var url = "print_invoices.php";
   redirect_by_post(url, pparameters, true);
}