<table id="lists_datatable" class="table table-hover table-bordered text-center">
 <thead style="text-align:center;font-weight:bold;">
  <tr class="success">
    <td>#</td>
    <td>NOMBRE</td>
    <td>APELLIDO</td>
    <td>CORREO</td>
    <td>CONTRASEÑA</td>
    <td>DIRECCION</td>
    <td>PAIS</td>
    <td>DEPARTAMENTO</td>
    <td>TELEFONO</td>    
    <td>FECHA NACIMIENTO</td>
    <td>FECHA DE REGISTRO</td>
    <td style="width:100px;">OPCIONES</td>
  </tr>
 </thead>
 <tbody>
  <?php
  $data = $link->query("SELECT cliente_id, cliente_nombre, cliente_apellido, cliente_correo, cliente_passw, cliente_pais, cliente_departamento, cliente_direccion, cliente_telefono, cliente_fecha_registro, cliente_fecha_nacimiento FROM clientes;");
  $n=0;
  while($data_clients = $data->fetch_assoc()){
    $clients_id             = $data_clients['cliente_id'];
    $clients_name           = $data_clients['cliente_nombre'];
    $clients_last_name      = $data_clients['cliente_apellido'];
    $clients_email          = $data_clients['cliente_correo'];
    $clients_passw          = $data_clients['cliente_passw'];
    $clients_address        = $data_clients['cliente_direccion'];
    $clients_country        = $data_clients['cliente_pais'];
    $clients_departaments   = $data_clients['cliente_departamento'];
    $clients_cellphone      = $data_clients['cliente_telefono'];
    $clients_date_born      = $data_clients['cliente_fecha_nacimiento'];
    $clients_date_register  = $data_clients['cliente_fecha_registro'];
    $n++;
    ?>
    <tr>
      <td><?=$n;?></td>
      <td><?=$clients_name;?></td>
      <td><?=$clients_last_name;?></td>
      <td><?=$clients_email;?></td>
      <td><?=$clients_passw;?></td>
      <td><?=$clients_address;?></td>
      <td><?=$clients_country;?></td>
      <td><?=$clients_departaments;?></td>
      <td><?=$clients_cellphone;?></td>
      <td><?=$clients_date_born;?></td>
      <td><?=$clients_date_register;?></td>
      <td style="text-align:center;">
        <div class="btn-group" role="group" aria-label="...">
           <button type="button" class="btn btn-info" onclick="edits_clients(<?=$clients_id;?>);" data-toggle="modal" data-target="#modal_edits_clients" data-backdrop="static">
              <span class="glyphicon glyphicon-pencil" aria-hidden="true"></span>
          </button>
          <button type="button" class="btn btn-danger" onclick="delete_clients('<?=$clients_id;?>', '1');">
          <span class="glyphicon glyphicon-trash" aria-hidden="true"></span>
          </button>
        </div>
      </td>
    </tr>
    <?php
  }
  ?>
 </tbody>
</table>