<?php
session_start();
date_default_timezone_set('America/El_Salvador');
include('../database.php');
if($_POST){
$options  =$_POST['options'];
  /*if($options=="SELECT"){
    include("product_list.php");
  }*/
  if($options=="REPORTS_SALES"){
    $date_i         = $_POST['date_i'];
    $date_f         = $_POST['date_f'];
    $sales_status   = $_POST['sales_status'];
    if($sales_status!='0'){
      $q="SELECT venta_id, cliente_nombre, cliente_apellido, venta_cantidad, venta_total, venta_estado FROM ventas_general INNER JOIN clientes ON (clientes.cliente_id=ventas_general.cliente_id) WHERE ventas_general.venta_estado='".$sales_status."' AND DATE(venta_fecha) BETWEEN '".$date_i."' AND '".$date_f."' ORDER BY venta_fecha DESC;"; 
    }else{
     $q="SELECT venta_id, cliente_nombre, cliente_apellido, venta_cantidad, venta_total, venta_estado FROM ventas_general INNER JOIN clientes ON (clientes.cliente_id=ventas_general.cliente_id) WHERE DATE(venta_fecha) BETWEEN '".$date_i."' AND '".$date_f."' ORDER BY venta_fecha DESC;";  
    }
    ?>
    <div class="panel panel-default">
      <div class="panel-body">
         <table class="table text-center" style="font-size:11px;">
         <tr class="info" style="font-weight:bold;">
          <td>#</td>
          <td>CODIGO DE VENTA</td>
          <td>CLIENTE</td>
          <td>CANTIDAD</td>
          <td>TOTAL</td>
          <td>ESTADO</td>
          <td>DETALLES</td>
          </tr>
          <?php
            $n=0;
            $data = $link->query($q);
            $num = $data->num_rows;
            if($num>0){
               while($data_sales  = $data->fetch_assoc()){
                $sales_id           = $data_sales['venta_id'];
                $clients_name       = $data_sales['cliente_nombre'];
                $clients_lastname   = $data_sales['cliente_apellido'];
                $sales_quantity     = $data_sales['venta_cantidad'];
                $sales_total        = $data_sales['venta_total'];
                $sales_status       = $data_sales['venta_estado'];
                $sales_total        = number_format(($sales_total), 2, '.', '');
                if($sales_status=="PENDIENTE"){
                    $sales_status_="<span class='label label-info'>".$sales_status."</span>";
                }else if($sales_status=="APROBADO"){
                    $sales_status_="<span class='label label-success'>".$sales_status."</span>";
                }else if($sales_status=="RECHAZADO"){
                    $sales_status_="<span class='label label-danger'>".$sales_status."</span>";
                }else{
                    $sales_status_="<span class='label label-default'>".$sales_status."</span>";
                }
                $n++;
                ?>
                  <tr>
                  <td><?=$n;?></td>
                  <td><?=$sales_id;?></td>
                  <td><?=$clients_name;?> <?=$clients_lastname;?></td>
                  <td><?=$sales_quantity;?></td>
                  <td>$ <?=$sales_total;?></td>
                  <td><?=$sales_status_;?></td>
                    <td>
                        <button type="button" class="btn btn-info btn-sm" onclick="sales_details('<?=$sales_id;?>', '<?=$sales_status;?>');" data-toggle="modal" data-target="#modal_details">
                        <i class="fa fa-file-text-o" aria-hidden="true"></i>
                        </button>
                    </td>
                  </tr>
                <?php
              }  
            }else{
              ?>
             <tr>
                <td colspan="7">
                    <div class="alert alert-danger" role="alert">
                        <b>NO</b>, SE ENCONTRARON REGISTROS.
                    </div>
                </td>
             </tr>
                <?php
            }
           
          ?>
         </table>
      </div>
    </div>
    <?php
  }
  if($options=="REPORTS_SALES_DETAILS"){
    $sales_id   = $_POST['sales_id'];
    $status     = $_POST['status'];
    ?>
    <div class="panel panel-info">
    <div class="panel-heading">
        <h3 class="panel-title">NUMERO DE ORDEN: <b><?=$sales_id;?></b> - ESTADO: <b><?=$status;?></b></h3>
      </div>
      <div class="panel-body">
        <?php
        $details ="SELECT productos.producto_id AS 'producto_id', productos.producto_nombre AS 'producto_nombre' , productos.producto_descripcion, ventas_detalle.venta_d_cantidad AS 'cantidad', venta_d_precio AS 'precio', productos.producto_cantidad AS 'existencia' FROM ventas_detalle INNER JOIN productos ON (productos.producto_id=ventas_detalle.producto_id) WHERE venta_id='$sales_id';";
        $select = $link->query($details);
        ?>
          
        <table class="table table-bordered table-hover text-center">
             <thead>
                <th class="text-center">#</th>
                <th class="text-center">Codigo</th>
                <th class="text-center">Producto</th>
                <th class="text-center">Precio</th>
                <th class="text-center">Cantidad</th>
                <th class="text-center">Total</th>
                <th class="text-center">Existencias</th>
             </thead>
             <tbody>
              <?php
             $num = $select->num_rows;
             $n=$mega_total=0;
             if($num>0){
                 while($data = $select->fetch_assoc()){
                     $product_id        = $data["producto_id"];
                     $product_name      = $data["producto_nombre"];
                     $product_price     = $data["precio"];
                     $product_quantity  = $data["cantidad"];
                     $product_stock     = $data["existencia"];
                     $total = ($product_quantity*$product_price);
                     $mega_total += $total;
                    $n++; 
                    ?>            
                    <tr>
                        <td><?=$n;?></td>
                        <td><?=$product_id;?></td>
                        <td><?=$product_name;?></td>
                        <td>$ <?=$product_price;?></td>
                        <td><?=$product_quantity;?></td>
                        <td><b>$ <?=$total;?></b></td>
                        <td><b><?=$product_stock;?></b></td>
                    </tr>
                    <?php
                 }
             }else{
               ?>
                 <tr>
                    <td colspan="8">
                        <div class="alert alert-warning text-center" role="alert"><b>NO</b> SE ENCONTRARON RESULTADOS</div>
                    </td>
                 </tr>
                <?php
             }
             ?>
             </tbody>
             <tfoot style="font-weight:bold;">
                <td colspan="5">SubTotal</td>
                <td>$ <?=$mega_total;?></td>
                <td>&nbsp;</td>
             </tfoot>
            </table> 
      </div>
      <div id="mini_request_modal_sales"></div>
      <div class="panel-footer text-center">
        <div class="btn-group" role="group" aria-label="...">
          <button type="button" class="btn btn-default" data-dismiss="modal" style="width:150px;">CERRAR</button>
          <?php
        if(($status=="RECHAZADO")||($status=="APROBADO")){
          ?>
            <button type="button" class="btn btn-success" style="width:150px;" disabled>APROVAR</button>
          <button type="button" class="btn btn-danger" style="width:150px;" disabled>RECHAZAR</button>
          <?php  
        }else{
          ?>
            <button type="button" class="btn btn-success" onclick="sales_aproved('<?=$sales_id;?>');" style="width:150px;">APROVAR</button>
          <button type="button" class="btn btn-danger" onclick="sales_rejected('<?=$sales_id;?>');" style="width:150px;">RECHAZAR</button>
          <?php
         }
         ?>
        </div>
      </div>
    </div>
    <?php
  }
   if($options=="REPORTS_SALES_REJECTED"){
    $sales_id   = $_POST['sales_id'];
       $q="UPDATE ventas_general SET ventas_general.venta_estado='RECHAZADO' WHERE ventas_general.venta_id='".$sales_id."';";
       $request = $link->query($q);
       if($request){
         ?>
            <script>
               $('#modal_details').modal('hide');
                generate_reports_sales();
            </script>
        <?php
       }
   }
   if($options=="REPORTS_SALES_APROVED"){
    $sales_id   = $_POST['sales_id'];
     $q="UPDATE ventas_general SET ventas_general.venta_estado='APROBADO' WHERE ventas_general.venta_id='".$sales_id."';";
       $request = $link->query($q);
       if($request){
           $details ="SELECT productos.producto_id AS 'producto_id',  ventas_detalle.venta_d_cantidad AS 'cantidad', productos.producto_cantidad AS 'existencia' FROM ventas_detalle INNER JOIN productos ON (productos.producto_id=ventas_detalle.producto_id) WHERE venta_id='$sales_id';";
            $select = $link->query($details);
            while($data = $select->fetch_assoc()){
             $product_id        = $data["producto_id"];
             $product_quantity  = $data["cantidad"];
             $product_stock     = $data["existencia"];
             $new_stock         = ($product_stock-$product_quantity);
              $request_stock = $link->query("UPDATE productos SET producto_cantidad='".$new_stock."' WHERE producto_id='".$product_id."';");
                if($request_stock){
                 $i++;   
                }
            }
         if($i>0){
           ?>
            <script>
               $('#modal_details').modal('hide');
                generate_reports_sales();
            </script>
        <?php  
         }
       }
   }
 
}
?>