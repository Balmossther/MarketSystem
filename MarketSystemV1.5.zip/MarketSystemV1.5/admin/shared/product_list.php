<table id="lists_datatable" class="table table-hover table-bordered text-center">
 <thead style="text-align:center;font-weight:bold;">
  <tr class="info">
    <td>#</td>
    <td>CODIGO</td>
    <td>CATEGORIA</td>
    <td>MODELO</td>
    <td>MARCA</td>
    <td>PRODUCTO</td>
    <td>DESCRIPCION</td>
    <td>PRECIO</td>
    <td>CANTIDAD</td>
    <td>FECHA REGISTRO</td>
    <td style="width:100px;">ACCIONES</td>
  </tr>
 </thead>
 <tbody>
  <?php
  $data = $link->query("SELECT productos.producto_id AS 'id', categorias.categoria_nombre AS 'category_name', modelo.modelo_nombre AS 'model_name', marca.marca_nombre AS 'brand_name', productos.producto_nombre AS 'product_name', productos.producto_descripcion AS 'product_description', productos.producto_precio AS 'product_price', productos.producto_cantidad AS 'product_quantity', productos.producto_fecha_registro AS 'product_date_registed' FROM productos INNER JOIN categorias ON (categorias.categoria_id=productos.categoria_id) INNER JOIN modelo ON (modelo.modelo_id=productos.modelo_id) INNER JOIN marca ON (marca.marca_id=productos.marca_id);");
  $n=0;
  while($data_products  = $data->fetch_assoc()){
    $product_id         = $data_products['id'];
    $category_name      = $data_products['category_name'];
    $model_name         = $data_products['model_name'];
    $brand_name         = $data_products['brand_name'];
    $product_name       = $data_products['product_name'];
    $product_description= $data_products['product_description'];
    $product_price      = $data_products['product_price'];
    $product_quantity   = $data_products['product_quantity'];
    $product_date_registed   = $data_products['product_date_registed'];
    $n++;
    ?>
    <tr>
      <td><?=$n;?></td>
      <td><?=$product_id;?></td>
      <td><?=$category_name;?></td>
      <td><?=$model_name;?></td>
      <td><?=$brand_name;?></td>
      <td><?=$product_name;?></td>
      <td><?=$product_description;?></td>
      <td><?=$product_price;?></td>
      <td><?=$product_quantity;?></td>
      <td><?=$product_date_registed;?></td>
      <td style="text-align:center;">
        <div class="btn-group" role="group" aria-label="...">
           <button type="button" class="btn btn-info" onclick="edits_products(<?=$product_id;?>);" data-toggle="modal" data-target="#modal_edits_products" data-backdrop="static">
              <span class="glyphicon glyphicon-pencil" aria-hidden="true"></span>
          </button>
          <button type="button" class="btn btn-danger" onclick="delete_products('<?=$product_id;?>', '1');">
          <span class="glyphicon glyphicon-trash" aria-hidden="true"></span>
          </button>
        </div>
      </td>
    </tr>
    <?php
  }
  ?>
 </tbody>
</table>