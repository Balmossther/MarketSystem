<?php
session_start();
include('../database.php');
if($_POST){
$options  =$_POST['options'];
  if($options=="SELECT"){
    include("product_list.php");
  }
  if($options=="SAVED"){
    $products_name          = $_POST['products_name'];
    $products_descriptions  = $_POST['products_descriptions'];
    $products_price         = $_POST['products_price'];
    $products_quantity      = $_POST['products_quantity'];
    $product_category_type  = $_POST['product_category_type'];
    $product_brand_type     = $_POST['product_brand_type'];
    $product_model_type     = $_POST['product_model_type'];
    $product_url_img	    = $_POST['url_img'];
    $date_time              = date("YmdHis");
     $request = $link->query("INSERT INTO productos (categoria_id, modelo_id, marca_id, producto_nombre, producto_descripcion, producto_precio, producto_cantidad, producto_fecha_registro, producto_url_imagen) VALUES('".$product_category_type."', '".$product_model_type."', '".$product_brand_type."', '".$products_name."', '".$products_descriptions."', '".$products_price."', '".$products_quantity."', '".$date_time."', '".$product_url_img."');");
    if($request){
      ?>
            <div class="alert alert-success alert-dismissible" role="alert">
              <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
              <strong>NUEVO PRODCUTO CREADO EXITOSAMENTE.</strong>
            </div>
       <script>
            selects_products();
            $("#modal_details").modal('hide');
      </script>
      <?php
    }
  }
  if($options=="DELETE"){
    $product_id =$_POST['product_id'];
    $request    = $link->query("DELETE FROM productos WHERE producto_id='".$product_id."';");
    if($request){
       ?> 
        <div class="alert alert-success alert-dismissible" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <strong>PRODCUTO ELIMINADO!</strong> EXITOSAMENTE.
         </div>
       <script>
           selects_products();
      </script>
      <?php
    }
  }
  if($options=="EDITS_CONTROLS"){
     $product_id =$_POST['product_id'];
     $data = $link->query("SELECT subcategoria_id, modelo_id, marca_id, producto_nombre, producto_descripcion, producto_precio, producto_cantidad, producto_url_imagen FROM productos WHERE producto_id='".$product_id."';");
     $data_products         = $data->fetch_array(MYSQLI_ASSOC);
     $product_category_id   = $data_products['subcategoria_id'];
     $product_model_id      = $data_products['modelo_id'];
     $product_brand_id      = $data_products['marca_id'];
     $product_name          = $data_products['producto_nombre'];
     $product_description   = $data_products['producto_descripcion'];
     $product_price         = $data_products['producto_precio'];
     $product_quantity      = $data_products['producto_cantidad'];
     $product_url_imagen    = $data_products['producto_url_imagen'];
    ?>
    <H4>EDITAR DATOS DE PRODUCTO</H4>
    <div class="row">
     <div class="col-md-12">
     <form>
        <div class="form-group">
          <label for="product_category_type">SELECCIONE UNA CATEGORIA:</label>
          <select class="form-control" name="edit_product_category_type" id="edit_product_category_type">
          <?php
          $data = $link->query("SELECT id_categoria, categoria_nombre FROM categorias;");
          while($data_brand = $data->fetch_assoc()){
            $category_id            = $data_brand['id_categoria'];
            $category_name          = $data_brand['categoria_nombre'];
              if($category_id==$product_category_id){
                ?>
                <option value='<?=$category_id?>' selected><?=$category_name;?></option>
                <?php  
              }else{
               ?>
                <option value='<?=$category_id?>'><?=$category_name;?></option>
                <?php   
              }
          }
          ?>
          </select>
      </div>
       <div class="form-group">
          <label for="product_brand_type">SELECCIONE UNA MARCA:</label>
          <select class="form-control" name="edit_product_brand_type" id="edit_product_brand_type">
          <?php
          $data = $link->query("SELECT marca_id, marca_nombre, marca_descripcion FROM marca;");
          while($data_brand = $data->fetch_assoc()){
            $brand_id            = $data_brand['marca_id'];
            $brand_name          = $data_brand['marca_nombre'];
              if($product_brand_id==$brand_id){
                 ?>
                <option value='<?=$brand_id?>' selected><?=$brand_name;?></option>
                <?php
              }else{
               ?>
                <option value='<?=$brand_id?>'><?=$brand_name;?></option>
                <?php   
              }
          }
          ?>
          </select>
      </div>
        <div class="form-group">
          <label for="product_model_type">SELECCIONE UN MODELO:</label>
          <select class="form-control" name="edit_product_model_type" id="edit_product_model_type">
          <?php
          $data = $link->query("SELECT modelo_id, marca_id, modelo_nombre, modelo_descripcion FROM modelo;");
          while($data_brand = $data->fetch_assoc()){
            $model_id            = $data_brand['modelo_id'];
            $model_brand_id      = $data_brand['marca_id'];
            $model_name          = $data_brand['modelo_nombre'];
            if($product_model_id==$model_id){
                ?>
            <option value='<?=$model_id?>' selected><?=$model_name;?></option>
            <?php
            }else{
                ?>
            <option value='<?=$model_id?>'><?=$model_name;?></option>
            <?php
            }
            
          }
          ?>
          </select>
      </div>              
        <div class="form-group">
          <label for="products_name">NOMBRE:</label>
          <input type="text" class="form-control" id="edit_products_name"  value="<?=$product_name;?>">
        </div>
         <div class="form-group">
          <label for="products_descriptions">DESCRIPCION:</label>
          <input type="text" class="form-control" id="edit_products_descriptions"  value="<?=$product_description;?>">
        </div>
         <div class="form-group">
          <label for="products_price">PRECIO UNIDAD:</label>
          <input type="text" class="form-control" id="edit_products_price"  value="<?=$product_price;?>">
        </div>
         <div class="form-group">
          <label for="products_quantity">CANTIDAD O EXISTENCIAS:</label>
          <input type="text" class="form-control" id="edit_products_quantity"  value="<?=$product_quantity;?>">
        </div>
		<div class="form-group">
			<label for="url_img">AGREGAR ENLACE DE INTERNET PARA IMAGEN:</label>
			<input type="text" class="form-control" id="edit_url_img" value="<?=$product_url_imagen;?>" required>
		</div>
        <hr>
        <input type="hidden" id="edit_product_id" value="<?=$product_id;?>" />
        <div class="row">
          <div class="col-md-12 text-center">
          <div class="btn-group" role="group" aria-label="options_buttons">
            <button type="button" class="btn btn-danger" data-dismiss="modal" style="width:150px;">SALIR</button>
            <button type="button" class="btn btn-success" style="width:150px;" onclick="edit_saved_products();">GUARDAR CAMBIOS</button>
          </div>
          </div>
        </div>
      </form>
     </div>
     </div>
  <?php
  }
  if($options=="EDITS"){
    $products_id            = $_POST['product_id'];
    $products_name          = $_POST['products_name'];
    $products_descriptions  = $_POST['products_descriptions'];
    $products_price         = $_POST['products_price'];
    $products_quantity      = $_POST['products_quantity'];
    $product_category_type  = $_POST['product_category_type'];
    $product_brand_type     = $_POST['product_brand_type'];
    $product_model_type     = $_POST['product_model_type'];
     $request = $link->query("UPDATE productos SET subcategoria_id='".$product_category_type."', modelo_id='".$product_model_type."', marca_id='".$product_brand_type."', producto_nombre='".$products_name."', producto_descripcion='".$products_descriptions."', producto_precio='".$products_price."', producto_cantidad='".$products_quantity."'  WHERE producto_id='".$products_id."';");
    if($request){
      ?>
      <div class="alert alert-success alert-dismissible" role="alert">
         <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
         <strong>PRODUCTO ACTUALIZADO EXITOSAMENTE.</strong>
      </div>
      <script>
        selects_products();
        $("#modal_edits_products").modal('hide');
      </script>
      <?php
    }
  }
}
?>