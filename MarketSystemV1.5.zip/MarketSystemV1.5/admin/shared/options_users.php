<?php
session_start();
include('../database.php');
if($_POST){
$options  =$_POST['options'];
  if($options=="SELECT"){
    include("users_list.php");
  }
  if($options=="SAVED"){
    $user_name      =$_POST['user_name'];
    $user_full_name =$_POST['user_full_name'];
    $passwd         =$_POST['passwd'];
    $email          =$_POST['email'];
    $user_type      =$_POST['user_type'];
    $date_time      = date("YmdHis");
     $request = $link->query("INSERT INTO usuarios (usuario_nombre, usuario_user, usuario_passw, usuario_correo, usuario_tipo, usuario_estado, usuario_fecha_registro) VALUES ('".$user_full_name."','".$user_name."','".$passwd."','".$email."','".$user_type."','ACTIVO','".$date_time."');");
    if($request){
      ?>
            <div class="alert alert-success alert-dismissible" role="alert">
              <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
              <strong>USUARIO INGRESADO EXITOSAMENTE.</strong>
            </div>
       <script>
        //window.location.replace('usuarios_admin.php?x=00')
            selects_user();
            $("#modal_details").modal('hide');
      </script>
      <?php
    }
  }
  if($options=="DELETE"){
  $user_id  =$_POST['user_id'];
    $request = $link->query("DELETE FROM usuarios WHERE usuario_id='".$user_id."' LIMIT 1;");
    if($request){
       ?> 
        <div class="alert alert-success alert-dismissible" role="alert">
              <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
              <strong>ELIMINADO!</strong> USUARIO ELIMINADO EXITOSAMENTE.
         </div>
       <script>
        //location.reload(true);
        //window.location.replace('usuarios_admin.php?x=01')
           selects_user();
      </script>
      <?php
    }
  }
  if($options=="EDITS_CONTROLS"){
      $user_id  =$_POST['user_id'];
      $data = $link->query("SELECT usuario_nombre, usuario_user, usuario_passw, usuario_correo, usuario_tipo, usuario_estado FROM usuarios WHERE usuario_id='".$user_id."';");
      $request  = $data->fetch_array(MYSQLI_ASSOC);
      $name     = $request['usuario_nombre'];
      $user     = $request['usuario_user'];
      $passw    = $request['usuario_passw'];
      $email    = $request['usuario_correo'];
      $type     = $request['usuario_tipo'];
      $estatus  = $request['usuario_estado'];
    ?>
    <H4>EDITAR DATOS DE USUARIOS</H4>
    <div class="row">
     <div class="col-md-12">
     <form>
        <div class="form-group">
          <label for="user_name">USUARIO:</label>
          <input type="text" class="form-control" id="edits_user_name" value="<?=$user;?>" required>
        </div>
         <div class="form-group">
          <label for="user_full_name">NOMBRE COMPLETO:</label>
          <input type="text" class="form-control" id="edits_user_full_name" value="<?=$name;?>" required>
        </div>
        <div class="form-group">
          <label for="passwd">CONTRASEÑA:</label>
          <input type="password" class="form-control" id="edits_passwd" value="<?=$passw;?>" required>
        </div>
        <div class="form-group">
          <label for="email">CORREO:</label>
          <input type="text" class="form-control" id="edits_email" value="<?=$email;?>"  required>
        </div>
         <div class="form-group">
          <label for="user_type">TIPO DE USUARIO:</label>
          <select class="form-control" name="edits_user_type" id="edits_user_type">
          <option value="ADMINISTRACION">ADMINISTRACION</option>
          <option value="VENDEDOR">VENDEDOR</option>
          </select>
        </div>
         <div class="form-group">
          <label for="user_type">ESTADO DE USUARIO:</label>
          <select class="form-control" name="edits_user_status" id="edits_user_status">
          <option value="ACTIVO">ACTIVO</option>
          <option value="DESACTIVADO">DESACTIVADO</option>
          </select>
        </div>
        <hr>
        <input type="hidden" id="edits_users_id" value="<?=$user_id;?>" />
        <div class="row">
          <div class="col-md-12 text-center">
          <div class="btn-group" role="group" aria-label="options_buttons">
            <button type="button" class="btn btn-danger" data-dismiss="modal" style="width:150px;">SALIR</button>
            <button type="button" class="btn btn-success" style="width:150px;" onclick="edits_users();">GUARDAR CAMBIOS</button>
          </div>
          </div>
        </div>
      </form>
     </div>
     </div>
  <?php
  }
  if($options=="EDITS"){
    $users_id       =$_POST['users_id'];
    $user_name      =$_POST['user_name'];
    $user_full_name =$_POST['user_full_name'];
    $passwd         =$_POST['passwd'];
    $email          =$_POST['email'];
    $user_type      =$_POST['user_type'];
    $user_status    =$_POST['user_status'];
    //$date_time      = date("YmdHis");
     $request = $link->query("UPDATE usuarios SET usuario_nombre='".$user_full_name."', usuario_user='".$user_name."', usuario_passw='".$passwd."', usuario_correo='".$email."', usuario_tipo='".$user_type."', usuario_estado='".$user_status."' WHERE usuario_id='".$users_id."';");
    if($request){
      ?>
            <div class="alert alert-success alert-dismissible" role="alert">
              <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
              <strong>USUARIO ACTUALIZADO EXITOSAMENTE.</strong>
            </div>
       <script>
        //window.location.replace('usuarios_admin.php?x=00')
            selects_user();
            $("#modal_edits_users").modal('hide');
      </script>
      <?php
    }
  }
}
?>