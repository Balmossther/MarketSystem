<?php
session_start();
include('database.php');
if(isset($_POST['username'])){
$username =$_POST['username'];
$password =$_POST['password'];
$data = $link->query("SELECT * FROM usuarios WHERE usuario_user='".$username."' LIMIT 1;");
$num = $data->num_rows;
if($num>0){
$request = $data->fetch_array(MYSQLI_ASSOC);
 if ($request['usuario_passw']==$password){
      $_SESSION["usuario"]  = $username;
      $_SESSION["clave"]    = $password;
      ?>
      <script type="text/javascript">
        window.location="index.php";
      </script> 
      <?php
 }else{
  ?>
  <script type="text/javascript">
   alert("Contraseña invalida!");
  </script> 
  <?php
 }
}else{
  ?>
  <script type="text/javascript">
   alert("Usuario NO registrado!");
  </script> 
  <?php
}

}else{
?>
<script type="text/javascript">
  window.location="login.php";
</script> 
<?php
}
?>