<?php
session_start();
if(isset($_SESSION["usuario"])){
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <?php include("includes/header.php");?>
  </head>
  <body>
  <?php
  include('database.php');
  include('menu.php');
  ?>
  <div class="container">
    <h2>
    <i class="fa fa-tags" aria-hidden="true"></i> 
    ADMINNISTRACION DE CATEGORIAS
    </h2>
    <div class="row">
      <div class="col-md-9">
        <div id="mini_request_category"></div>
      </div>
      <div class="col-md-3 text-right">
        <button type="button" class="btn btn-success btn-md" data-toggle="modal" data-target="#modal_details" data-backdrop="static">
          <span class="glyphicon glyphicon-plus" aria-hidden="true"></span> NUEVA CATEGORIA
        </button>
      </div>
    </div>
    <br>
    <div id="request_list">
    <?php include("shared/category_list.php");?>  
    </div>
   </div>
   <div class="modal fade" id="modal_details" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-md">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
          </div>
          <div class="modal-body">
            <div id="report_data_details">
            <H4>NUEVA CATEGORIA</H4>
             <div class="row">
             <div class="col-md-12">
             <form>
                <div class="form-group">
                  <label for="user_name">NOMBRE:</label>
                  <input type="text" class="form-control" id="category_name" required>
                </div>
                 <div class="form-group">
                  <label for="user_full_name">DESCRIPCION:</label>
                  <input type="text" class="form-control" id="category_description" required>
                </div>
                <hr>
                <div class="row">
                  <div class="col-md-12 text-center">
                  <div class="btn-group" role="group" aria-label="options_buttons">
                    <button type="button" class="btn btn-danger" data-dismiss="modal" style="width:150px;">SALIR</button>
                    <button type="button" class="btn btn-success" style="width:150px;" onclick="saved_category();">GUARDAR DATOS</button>
                  </div>
                  </div>
                </div>
              </form>
             </div>
             </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="modal fade" id="modal_edits_category" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-md">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
          </div>
          <div class="modal-body">
            <div id="report_data_edits_category">
            </div>
          </div>
        </div>
      </div>
    </div>
   <footer>
     <?php include("includes/footer.php");?>
   </footer>
  </body>
</html>
<?php } ?>