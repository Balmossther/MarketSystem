  <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
   <!-- Include all compiled plugins (below), or include individual files as needed -->
<div class="navbar navbar-default navbar-fixed-bottom">
    <div class="container">
      <p class="navbar-text pull-left"><b>INGENIERIA EN SISTEMAS </b>- &copy - GRUPO C - <?php echo date('Y');?>
      </p>
   </div>
</div>