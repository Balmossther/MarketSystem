<?php
  if($_GET){
    $options        = $_GET["options"];
    if($options=="brands"){
      $title="PRODUCTOS POR MARCAS SELECCIONADAS";  
    }
    else if($options=="category"){
      $title="PRODUCTOS POR CATEGORIA";  
    }else if($options=="search"){
     $title="BUSQUEDA DE PRODUCTOS";   
    }
    }else{
      $title="PRODUCTOS MAS NUEVOS";
     }
?>
<div class="panel panel-success">
  <div class="panel-heading"><?=$title;?></div>
  <div class="panel-body">
  <input type="hidden" id="clients_id_online" value="<?=$clients_id;?>" />
   <?php
      if($_GET){
       
        if($options=="brands"){
        $id_selected    = $_GET["id"];
         $q="SELECT productos.producto_id AS 'id', categorias.categoria_nombre AS 'category_name', modelo.modelo_nombre AS 'model_name', marca.marca_nombre AS 'brand_name', productos.producto_nombre AS 'product_name', productos.producto_descripcion AS 'product_description', productos.producto_precio AS 'product_price', productos.producto_cantidad AS 'product_quantity', productos.product_url_img AS 'url_img' FROM productos INNER JOIN categorias ON (categorias.categoria_id=productos.categoria_id) INNER JOIN modelo ON (modelo.modelo_id=productos.modelo_id) INNER JOIN marca ON (marca.marca_id=productos.marca_id) WHERE productos.marca_id='".$id_selected."' ORDER BY productos.producto_nombre;";
        }
        else if($options=="category"){
            $id_selected    = $_GET["id"];
           $q="SELECT productos.producto_id AS 'id', categorias.categoria_nombre AS 'category_name', modelo.modelo_nombre AS 'model_name', marca.marca_nombre AS 'brand_name', productos.producto_nombre AS 'product_name', productos.producto_descripcion AS 'product_description', productos.producto_precio AS 'product_price', productos.producto_cantidad AS 'product_quantity', productos.product_url_img AS 'url_img' FROM productos INNER JOIN categorias ON (categorias.categoria_id=productos.categoria_id) INNER JOIN modelo ON (modelo.modelo_id=productos.modelo_id) INNER JOIN marca ON (marca.marca_id=productos.marca_id) WHERE productos.categoria_id='".$id_selected."' ORDER BY productos.producto_nombre;"; 
        }else if($options=="search"){
           $search    = $_GET["search"];
           $q="SELECT productos.producto_id AS 'id', categorias.categoria_nombre AS 'category_name', modelo.modelo_nombre AS 'model_name', marca.marca_nombre AS 'brand_name', productos.producto_nombre AS 'product_name', productos.producto_descripcion AS 'product_description', productos.producto_precio AS 'product_price', productos.producto_cantidad AS 'product_quantity', productos.product_url_img AS 'url_img' FROM productos INNER JOIN categorias ON (categorias.categoria_id=productos.categoria_id) INNER JOIN modelo ON (modelo.modelo_id=productos.modelo_id) INNER JOIN marca ON (marca.marca_id=productos.marca_id) WHERE productos.producto_nombre LIKE '%".$search."%' ORDER BY productos.producto_nombre;"; 
        }
      }else{
        $q="SELECT productos.producto_id AS 'id', categorias.categoria_nombre AS 'category_name', modelo.modelo_nombre AS 'model_name', marca.marca_nombre AS 'brand_name', productos.producto_nombre AS 'product_name', productos.producto_descripcion AS 'product_description', productos.producto_precio AS 'product_price', productos.producto_cantidad AS 'product_quantity', productos.product_url_img AS 'url_img' FROM productos INNER JOIN categorias ON (categorias.categoria_id=productos.categoria_id) INNER JOIN modelo ON (modelo.modelo_id=productos.modelo_id) INNER JOIN marca ON (marca.marca_id=productos.marca_id) ORDER BY productos.producto_fecha_registro DESC LIMIT 5;";  
      }
    $data = $link->query($q);
    while($data_products  = $data->fetch_assoc()){
        $product_id         = $data_products['id'];
        $category_name      = $data_products['category_name'];
        $model_name         = $data_products['model_name'];
        $brand_name         = $data_products['brand_name'];
        $product_name       = $data_products['product_name'];
        $product_description= $data_products['product_description'];
        $product_price      = number_format($data_products['product_price'], 2, '.', '');
        $product_quantity   = $data_products['product_quantity'];
        $product_url_img   = ($data_products['url_img']!="")?$data_products['url_img']:"img/no_imagen.png";
      ?>
      <div class="panel panel-primary">
        <div class="panel-heading">
        <h3 class="panel-title"><?=$product_name;?></h3>
        </div>
        <div class="panel-body">
        <div class="row">
          <div class="col-lg-6">
          <img src="<?=$product_url_img;?>" alt="<?=$product_name;?>" class="img-thumbnail"  >
          </div>
          <div class="col-lg-6">
          <p> <?=$product_description;?> </p>
          <p>
          $<?=$product_price;?>
          </p>
          </div>
        </div>
        <div class="text-right">
        <button type="button" class="btn btn-success btn-lg" onclick="products_add_list('<?=$product_id;?>');"><span class="glyphicon glyphicon-plus-sign" aria-hidden="true"></span> AGREGAR</button>
        <button type="button" class="btn btn-info btn-lg" onclick="products_details('<?=$product_id;?>');"><span class="glyphicon glyphicon-plus-sign" aria-hidden="true"></span> MOSTRAR DETALLE</button>
        </div>
        </div>
      </div>
      <?php
    }
    ?>
  </div>
</div>