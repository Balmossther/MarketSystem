<nav class="navbar navbar-default">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="index.php"><img src="img/logo.png" height="35px"></a>
    </div>
	<ul class="nav navbar-nav">
      <?php 
	  $request_menu = $link->query("SELECT categoria_id, categoria_nombre FROM categorias");
	  while($data_read_category = $request_menu->fetch_assoc()){
	   $category_id		= $data_read_category['categoria_id'];
	   $category_name 	= $data_read_category['categoria_nombre'];
	   ?>
     	<li>
		<a href="products.php?options=category&id=<?=$category_id;?>" > <?=$category_name;?></a>
		</li>
      <!--   <li class="dropdown">-->
         <!--  <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><?php echo $datos_c['categoria_nombre']?><span class="caret"></span></a> -->
        <!--   <ul class="dropdown-menu">-->
            <!--  <li><a href="#"> </a></li> -->
             <!-- <li><a href="#"> </a></li> -->
      
         <!--  </ul>-->
       <!--  </li>-->
		<?php 
		}
		?>
    </ul>
	<ul class="nav navbar-nav navbar-right">
    <li>
    <a href="#" data-toggle="modal" data-target="#ModalShoppingCart" onclick="view_list_cars();">
      <i class="fa fa-cart-arrow-down" aria-hidden="true"></i>
      MI CARRITO
    </a>
    </li>
    <?php
    if(isset($_SESSION["clients_name"])){
    $clients_id = $_SESSION["clients_id"];
    ?>
    <li class="dropdown">
    <a class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
      <i class="fa fa-user" aria-hidden="true"></i>
      <b><?=$_SESSION["clients_name"];?></b>
       <span class="caret"></span>
    </a>
    <ul class="dropdown-menu">
     <li>
    <a onclick="login_close_clients();" >
    <i class="fa fa-sign-in" aria-hidden="true"></i>
    CERRAR SESION
    </a>
    </li>
    <li role="separator" class="divider"></li>
    </ul>
    </li>
    <?php
    }else{
    $clients_id = 0;
    ?>
    <li class="dropdown">
    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
    <i class="fa fa-user" aria-hidden="true"></i> 
    MI CUENTA 
    <span class="caret"></span>
    </a>
    <ul class="dropdown-menu">
    <li>
    <a href="#" data-toggle="modal" data-target="#ModalLogin">
    <i class="fa fa-sign-in" aria-hidden="true"></i>
    INICIAR SESION
    </a>
    </li>
    <li role="separator" class="divider"></li>
      <li>
    <a href="#" data-toggle="modal" data-target="#ModalRegisters">
    <i class="fa fa-user-plus" aria-hidden="true"></i>
    REGISTRATE
    </a>
    </li>
    </ul>
    </li>
    <?php
    }
    ?>
   </ul>  
	<!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>
<div id="mini_request_header"></div>
<!-- Modal -->
<div class="modal fade" id="ModalLogin" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">INICIO DE SESION</h4>
      </div>
      <div class="modal-body">
      <form>
      <div class="form-group">
        <label for="exampleInputEmail1">CORREO:</label>
        <input type="text" class="form-control" id="login_user" name="login_user" placeholder="INGRESE SU CORREO">
      </div>
      <div class="form-group">
        <label for="exampleInputPassword1">CONTRASEÑA:</label>
        <input type="password" class="form-control" id="login_passwd" name="login_passwd" placeholder="INGRESE SU CONTRASEÑA">
      </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">CANCELAR</button>
        <button type="button" class="btn btn-success" onclick="login_clients();">INGRESAR</button>
        </form>
      </div>
    </div>
  </div>
</div>
<!-- Modal -->

<div class="modal fade" id="ModalRegisters" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">REGISTRO DE CLIENTE</h4>
      </div>
      <div class="modal-body">
        <form>
          <div class="form-group">
            <label for="user_name">NOMBRE:</label>
            <input type="text" class="form-control" id="clients_name" required>
          </div>
          <div class="form-group">
            <label for="user_full_name">APELLIDO:</label>
            <input type="text" class="form-control" id="clients_last_name" required>
          </div>
           <div class="form-group">
            <label for="passwd">CONTRASEÑA:</label>
            <input type="password" class="form-control" id="clients_passwd" required>
          </div>
          <div class="form-group">
            <label for="email">CORREO:</label>
            <input type="text" class="form-control" id="clients_email" required>
          </div>
          <div class="form-group">
            <label for="email">TELEFONO:</label>
            <input type="text" class="form-control" id="clients_cellphone" required>
          </div>
           <div class="form-group">
            <label for="email">FECHA DE NACIMIENTO:</label>
            <input type=text id='clients_date_borth' name='clients_date_borth' class="form-control" style="width:125px;text-align:center;cursor:pointer;">
            <script type="text/javascript">
              $( "#clients_date_borth" ).datepicker({  maxDate: 0 });
            </script>
          </div>
           <div class="form-group">
            <label for="email">DIRECCION:</label>
            <textarea class="form-control" id="clients_address" style="resize:none;"></textarea>
          </div>
           <div class="form-group">
            <label for="user_type">PAIS:</label>
            <select class="form-control" name="clients_country" id="clients_country">
            <option value="EL SALVADOR">EL SALVADOR</option>
            <!--<option value="GUATEMALA">GUATEMALA</option>
            <option value="HONDURAS">HONDURAS</option>
            <option value="NICARAGUA">NICARAGUA</option>
            <option value="COSTA RICA">COSTA RICA</option>
            <option value="BELICE">BELICE</option>
            <option value="PANAMA">PANAMA</option>-->
            </select>
          </div>
           <div class="form-group">
            <label for="user_type">DEPARTAMENTO:</label>
            <select class="form-control" name="clients_departaments" id="clients_departaments">
            <option value="SAN SALVADOR">SAN SALVADOR</option>
            <option value="SAN MIGUEL">SAN MIGUEL</option>
            <option value="LA UNION">LA UNION</option>
            <option value="MORAZAN">MORAZAN</option>
            <option value="USULUTAN">USULUTAN</option>
            </select>
          </div>
        </form>
      </div>
      <div class="modal-footer">
        <div class="row">
          <div class="col-md-12 text-center">
          <div class="btn-group" role="group" aria-label="options_buttons">
            <button type="button" class="btn btn-danger" data-dismiss="modal" style="width:150px;">SALIR</button>
            <button type="button" class="btn btn-success" style="width:150px;" onclick="saved_new_clients();">GUARDAR DATOS</button>
          </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Modal -->


<div class="modal fade" id="ModalShoppingCart" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">CARRITO DE COMPRAS</h4>
      </div>
          <div class="modal-body" id="id_lista_carrito"> </div>
      <div class="modal-footer">
      </div>
    </div>
  </div>
</div>
