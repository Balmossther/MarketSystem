<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
  <!-- Indicators -->
  <ol class="carousel-indicators">
    <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
    <li data-target="#carousel-example-generic" data-slide-to="1"></li>
    <li data-target="#carousel-example-generic" data-slide-to="2"></li>
    <li data-target="#carousel-example-generic" data-slide-to="3"></li>
  </ol>

  <!-- Wrapper for slides -->
  <div class="carousel-inner" role="listbox">
    <div class="item active">
     <center><img src="img/slider/slider1.jpg" height="275px"></center> 
      <div class="carousel-caption">
        LO MEJOR EN EQUIPOS.
      </div>
    </div>
    <div class="item">
      <center><img src="img/slider/slider2.jpg" height="275px"> </center>
      <div class="carousel-caption">
        LA MEJOR VARIEDAD EN ACCESORIOS
      </div>
    </div>
    <div class="item">
      <center><img src="img/slider/slider3.jpg" height="275px"> </center>
      <div class="carousel-caption">
        LA MAYORIA DE MARCAS REGISTRADAS
      </div>
    </div>
	<div class="item">
      <center><img src="img/slider/slider4.jpg" height="275px"> </center>
      <div class="carousel-caption">
        LOS MEJORES PRECIOS Y OPCIONES DE ENVIO.
      </div>
    </div>
  </div>

  <!-- Controls -->
  <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>