<?php
session_start();
date_default_timezone_set('America/El_Salvador');
include('../includes/database.php');
if(isset($_POST['options'])){
 $options   = $_POST['options'];
 if($options=="login"){
   if(isset($_POST['username'])){
    $username   = $_POST['username'];
    $passsw     = $_POST['passsw'];
    $data = $link->query("SELECT * FROM clientes WHERE cliente_correo='".$username."' LIMIT 1;");
    $num = $data->num_rows;
    if($num>0){
    $request = $data->fetch_array(MYSQLI_ASSOC);
     if ($request['cliente_passw']==$passsw){
          $_SESSION["clients_name"]  = $username;
          $_SESSION["clients_id"]    = $request['cliente_id'];
          ?>
          <script type="text/javascript">
            window.location="index.php";
          </script> 
          <?php
     }else{
      ?>
      <script type="text/javascript">
       alert("Contraseña invalida!");
      </script> 
      <?php
     }
    }else{
      ?>
      <script type="text/javascript">
       alert("Usuario NO registrado!");
      </script> 
      <?php
    }
   }  
 }
 if($options=="closing"){
   session_destroy();
   ?>
  <script type="text/javascript">
    window.location="index.php";
  </script> 
  <?php
 }
 if($options=="saved_new_clients"){
  $clients_name           =$_POST['clients_name'];
  $clients_last_name      =$_POST['clients_last_name'];
  $clients_passwd         =$_POST['clients_passwd'];
  $clients_email          =$_POST['clients_email'];
  $clients_cellphone      =$_POST['clients_cellphone'];
  $clients_date_borth     =$_POST['clients_date_borth'];
  $clients_address        =$_POST['clients_address'];
  $clients_country        =$_POST['clients_country'];
  $clients_departaments   =$_POST['clients_departaments'];
  $date_time              = date("YmdHis");
  $q="INSERT INTO clientes (cliente_nombre, cliente_apellido, cliente_correo, cliente_passw, cliente_pais, cliente_departamento, cliente_direccion, cliente_telefono, cliente_fecha_registro, cliente_fecha_nacimiento) VALUES ('".$clients_name."', '".$clients_last_name."', '".$clients_email."', '".$clients_passwd."', '".$clients_country."', '".$clients_departaments."', '".$clients_address."', '".$clients_cellphone."', '".$date_time."', '".$clients_date_borth."');";
  $request = $link->query($q);
  if($request){
   ?>
   <script>
        $("#ModalRegisters").modal('hide');
        alert("CLIENTE REGISTRADO EXITOSAMENTE");
  </script>
   <?php
  }
 }
}
else{
?>
<script type="text/javascript">
  window.location="index.php";
</script> 
<?php
}
?>