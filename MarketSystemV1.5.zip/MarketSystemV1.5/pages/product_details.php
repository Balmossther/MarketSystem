  <input type="hidden" id="clients_id_online" value="<?=$clients_id;?>" />
   <?php
      if($_POST){
        $options     = $_POST["options"];
        if($options=="details"){
            $product_id  = $_POST["product_id"];
            $q="SELECT productos.producto_id AS 'id', categorias.categoria_nombre AS 'category_name', modelo.modelo_nombre AS 'model_name', marca.marca_nombre AS 'brand_name', productos.producto_nombre AS 'product_name', productos.producto_descripcion AS 'product_description', productos.producto_precio AS 'product_price', productos.producto_cantidad AS 'product_quantity', productos.product_url_img AS 'url_img' FROM productos INNER JOIN categorias ON (categorias.categoria_id=productos.categoria_id) INNER JOIN modelo ON (modelo.modelo_id=productos.modelo_id) INNER JOIN marca ON (marca.marca_id=productos.marca_id) WHERE productos.producto_id='".$product_id."';";  
            $data = $link->query($q);
            ?>
            <div class="panel panel-success">
              <div class="panel-heading">DETALLES DEL PRODUCTO</div>
              <div class="panel-body">
            <?php
            while($data_products  = $data->fetch_assoc()){
                $product_id         = $data_products['id'];
                $category_name      = $data_products['category_name'];
                $model_name         = $data_products['model_name'];
                $brand_name         = $data_products['brand_name'];
                $product_name       = $data_products['product_name'];
                $product_description= $data_products['product_description'];
                $product_price      = number_format($data_products['product_price'], 2, '.', '');
                $product_quantity   = $data_products['product_quantity'];
                $product_url_img   = ($data_products['url_img']!="")?$data_products['url_img']:"img/no_imagen.png";
              ?>
              <div class="panel panel-primary">
                <div class="panel-heading">
                <h3 class="panel-title"><?=$product_name;?></h3>
                </div>
                <div class="panel-body">
                <div class="row">
                  <div class="col-lg-6">
                  <img src="<?=$product_url_img;?>" alt="<?=$product_name;?>" class="img-thumbnail"  >
                  </div>
                  <div class="col-lg-6">
                  <p> <?=$product_description;?> </p>
                  <p>
                  $<?=$product_price;?>
                  </p>
                  </div>
                </div>
                <div class="text-right">
                <button type="button" class="btn btn-success btn-lg" onclick="products_add_list('<?=$product_id;?>');"><span class="glyphicon glyphicon-plus-sign" aria-hidden="true"></span> AGREGAR</button>
                </div>
                </div>
              </div>
              <?php
            }
             ?>
          </div>
        </div>
        <?php
        }
        if($options=="previous_invoice"){
          $clients_online  = $_POST["clients_online"];
          $q = "SELECT productos.producto_id AS 'product_id', producto_nombre, producto_precio, lista_compra_cantidad  FROM lista_compras INNER JOIN productos ON (productos.producto_id = lista_compras.producto_id) WHERE lista_compras.cliente_id='".$clients_online."';";
         $select = $link->query($q);
        ?>
        <div class="panel panel-primary">
        <div class="panel-heading">
        <h3 class="panel-title">ORDEN DE COMPRA</h3>
        </div>
        <div class="panel-body">
        <h5>INFORMACION GENERAL DEL CLIENTE</h5>
        <div class="well">
        <?php
        $clients_q = "SELECT cliente_nombre, cliente_apellido, cliente_correo, cliente_direccion, cliente_departamento, cliente_pais, cliente_telefono FROM clientes WHERE cliente_id='".$clients_online."';";
        $data_clients = $link->query($clients_q);
        $request_clients    = $data_clients->fetch_array(MYSQLI_ASSOC);
        $clients_name       = $request_clients["cliente_nombre"];
        $clients_lastname   = $request_clients["cliente_apellido"];
        $clients_email      = $request_clients["cliente_correo"];
        $clients_address    = $request_clients["cliente_direccion"];
        $clients_departaments = $request_clients["cliente_departamento"];
        $clients_country    = $request_clients["cliente_pais"];
        $clients_telephone  = $request_clients["cliente_telefono"];
        ?>
        
        <div class="row">
            <div class="col-md-4">
                FACTURAR A NOMBRE DE:
            </div>
            <div class="col-md-8">
                <b>
                    <?=$clients_name;?> <?=$clients_lastname;?>
                </b>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4">
                E-MAIL:
            </div>
            <div class="col-md-8">
                <b>
                    <?=$clients_email;?>
                </b>
            </div>
        </div>    
        <div class="row">
            <div class="col-md-4">
                NUMERO DE CONTACTO:
            </div>
            <div class="col-md-8">
                <b>
                    <?=$clients_telephone;?>
                </b>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4">
                DIRECCION:
            </div>
            <div class="col-md-8">
                <b>
                    <?=$clients_address;?>
                </b>
            </div>
        </div>
        <div class="row">
             <div class="col-md-4">
                DEPARTAMENTO:
            </div>
            <div class="col-md-8">
                <b>
                    <?=$clients_departaments;?>
                </b>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4">
                PAIS:
            </div>
            <div class="col-md-8">
                <b>
                    <?=$clients_country;?>
                </b>
            </div>
        </div>
        </div>
        <h5>LISTA DE PRODUCTOS</h5>
        <table class="table table-bordered table-hover text-center">
             <thead>
                <th class="text-center">#</th>
                <th class="text-center">Codigo</th>
                <th class="text-center">Producto</th>
                <th class="text-center">Precio</th>
                <th class="text-center">Cantidad</th>
                <th class="text-center">Total</th>
                <th class="text-center">Accion</th>
             </thead>
             <tbody>
              <?php
             $num = $select->num_rows;
             $n=$mega_total=0;
             if($num>0){
                 while($data = $select->fetch_assoc()){
                     $product_id        = $data["product_id"];
                     $product_name      = $data["producto_nombre"];
                     $product_price     = $data["producto_precio"];
                     $product_quantity  = $data["lista_compra_cantidad"];
                     $total = ($product_quantity*$product_price);
                     $mega_total += $total;
                    $n++; 
                    ?>            
                    <tr>
                        <td><?=$n;?></td>
                        <td><?=$product_id;?></td>
                        <td><?=$product_name;?></td>
                        <td>$ <?=$product_price;?></td>
                        <td><?=$product_quantity;?></td>
                        <td><b>$ <?=$total;?></b></td>
                        <td>
                            <a href="#" class="btn btn-default" onclick="products_details('<?=$product_id;?>');" >  <span class="glyphicon glyphicon-search" aria-hidden="true"></span></a>
                            <a href="#" class="btn btn-danger" onclick="products_delete('<?=$product_id;?>', '<?=$clients_online;?>');">  <span class="glyphicon glyphicon-trash" aria-hidden="true"></span></a>
                        </td>
                    </tr>
                    <?php
                 }
             }else{
               ?>
                 <tr>
                    <td colspan="7">
                        <div class="alert alert-warning text-center" role="alert"><b>NO</b> SE ENCONTRARON RESULTADOS</div>
                    </td>
                 </tr>
                <?php
             }
             ?>
             </tbody>
             <tfoot style="font-weight:bold;">
                <td colspan="5">SubTotal</td>
                <td>$ <?=$mega_total;?></td>
                <td>&nbsp;</td>
             </tfoot>
            </table>
            <div id="mini_request_order"></div>
            <div class="well text-align">
                <center>
                <button type="button" class="btn btn-info" onclick="send_process_invoice_print();" style="width:250px;">IMPRIMIR ORDEN</button>
                <button type="button" class="btn btn-success" onclick="send_process_invoice();" style="width:250px;">GENERAR ENVIO DE ORDEN</button>
                </center>
            </div>
        </div>
        </div>
    <?php
    }
        if($options=="print_invoice"){
          $clients_online  = $_POST["clients_online"];
          $q = "SELECT productos.producto_id AS 'product_id', producto_nombre, producto_precio, lista_compra_cantidad  FROM lista_compras INNER JOIN productos ON (productos.producto_id = lista_compras.producto_id) WHERE lista_compras.cliente_id='".$clients_online."';";
         $select = $link->query($q);
        ?>
        <div class="panel panel-primary">
        <div class="panel-heading">
        <h3 class="panel-title"><img src="img/logo.png" height="35px"> ORDEN DE COMPRA</h3>
        </div>
        <div class="panel-body">
        <h6>INFORMACION GENERAL DEL CLIENTE</h6>
        <div class="well">
        <?php
        $clients_q = "SELECT cliente_nombre, cliente_apellido, cliente_correo, cliente_direccion, cliente_departamento, cliente_pais, cliente_telefono FROM clientes WHERE cliente_id='".$clients_online."';";
        $data_clients = $link->query($clients_q);
        $request_clients    = $data_clients->fetch_array(MYSQLI_ASSOC);
        $clients_name       = $request_clients["cliente_nombre"];
        $clients_lastname   = $request_clients["cliente_apellido"];
        $clients_email      = $request_clients["cliente_correo"];
        $clients_address    = $request_clients["cliente_direccion"];
        $clients_departaments = $request_clients["cliente_departamento"];
        $clients_country    = $request_clients["cliente_pais"];
        $clients_telephone  = $request_clients["cliente_telefono"];
        ?>
        
        <div class="row">
            <div class="col-md-4">
                FACTURAR A NOMBRE DE:
            </div>
            <div class="col-md-8">
                <b>
                    <?=$clients_name;?> <?=$clients_lastname;?>
                </b>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4">
                E-MAIL:
            </div>
            <div class="col-md-8">
                <b>
                    <?=$clients_email;?>
                </b>
            </div>
        </div>    
        <div class="row">
            <div class="col-md-4">
                NUMERO DE CONTACTO:
            </div>
            <div class="col-md-8">
                <b>
                    <?=$clients_telephone;?>
                </b>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4">
                DIRECCION:
            </div>
            <div class="col-md-8">
                <b>
                    <?=$clients_address;?>
                </b>
            </div>
        </div>
        <div class="row">
             <div class="col-md-4">
                DEPARTAMENTO:
            </div>
            <div class="col-md-8">
                <b>
                    <?=$clients_departaments;?>
                </b>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4">
                PAIS:
            </div>
            <div class="col-md-8">
                <b>
                    <?=$clients_country;?>
                </b>
            </div>
        </div>
        </div>
        <h6>LISTA DE PRODUCTOS</h6>
        <table class="table table-bordered table-hover text-center">
             <thead>
                <th class="text-center">#</th>
                <th class="text-center">Codigo</th>
                <th class="text-center">Producto</th>
                <th class="text-center">Precio</th>
                <th class="text-center">Cantidad</th>
                <th class="text-center">Total</th>
             </thead>
             <tbody>
              <?php
             $num = $select->num_rows;
             $n=$mega_total=0;
             if($num>0){
                 while($data = $select->fetch_assoc()){
                     $product_id        = $data["product_id"];
                     $product_name      = $data["producto_nombre"];
                     $product_price     = $data["producto_precio"];
                     $product_quantity  = $data["lista_compra_cantidad"];
                     $total = ($product_quantity*$product_price);
                     $mega_total += $total;
                    $n++; 
                    ?>            
                    <tr>
                        <td><?=$n;?></td>
                        <td><?=$product_id;?></td>
                        <td><?=$product_name;?></td>
                        <td>$ <?=$product_price;?></td>
                        <td><?=$product_quantity;?></td>
                        <td><b>$ <?=$total;?></b></td>
                    </tr>
                    <?php
                 }
             }else{
               ?>
                 <tr>
                    <td colspan="7">
                        <div class="alert alert-warning text-center" role="alert"><b>NO</b> SE ENCONTRARON RESULTADOS</div>
                    </td>
                 </tr>
                <?php
             }
             ?>
             </tbody>
             <tfoot style="font-weight:bold;">
                <td colspan="5">SubTotal</td>
                <td>$ <?=$mega_total;?></td>
             </tfoot>
            </table>
        </div>
        </div>
    <?php
    }
  }
?>
   